# Reglas Operativas, CTAs y Errores Globales

*Protocolo de configuración inicial de 6 pasos. CTAs permitidos por tipo. Reglas matriciales de transparencia de precio. Reglas de seguridad transversales no negociables. Errores comunes globales.*

---

# PARTE V — REGLAS OPERATIVAS Y CTAS

## 22. Protocolo de configuración inicial de la skill

Antes de generar la primera pieza, la skill ejecuta un protocolo de configuración. Este protocolo es lo que diferencia un sistema que produce contenido genérico de uno que produce contenido afilado al avatar.

### 22.1 Pasos del protocolo

**Paso 1 — Brief de Marca:**
- Pregunta al usuario: *"¿Quieres llenar el Brief en modo libre (cuéntame tu historia como a un amigo) o en modo estructurado (preguntas sección por sección)?"*
- Si modo libre: recibe el relato, identifica secciones cubiertas, dispara 3–5 preguntas puntuales.
- Si modo estructurado: ejecuta las 15 secciones del brief en orden.
- Resultado: brief completo guardado.

**Paso 2 — Tipo de negocio y etapa de cuenta:**
- *"¿Qué tipo de negocio tienes?"* (5 opciones de la sección 19)
- *"¿En qué etapa está tu cuenta?"* (4 opciones de la sección 20)
- *"¿Estás en lanzamiento activo o pre-lanzamiento?"* (sí/no, fecha de apertura si sí)
- Resultado: matriz de proporciones cargada.

**Paso 3 — Banco de Auto-Aplicación:**
- *"Necesito que me listes mínimo 8 momentos en los últimos 24 meses donde lo que vendes te ayudó a ti mismo. Para cada uno: cuándo, qué situación, qué aplicaste, cómo te fue, qué le diría a un cliente que duda."*
- Si el usuario no tiene 8 listos, la skill asiste con preguntas para extraerlos.
- Resultado: banco de mínimo 8 momentos guardado.

**Paso 4 — Mapa de Dolores:**
- *"¿Tienes mapeados los dolores de tu avatar en 4 niveles (externo, interno, relacional, filosófico)?"*
- Si sí: el usuario los pega.
- Si no: la skill genera propuesta de 4 niveles × 5 dolores cada uno (20 dolores) basada en avatar y oferta. Aplica Test de Amenaza Concreta a los filosóficos.
- Resultado: mapa validado y guardado.

**Paso 5 — Naturaleza de la oferta principal:**
- *"¿Cuál es tu oferta principal y su rango de precio?"*
- Opciones: producto físico / digital low-ticket / digital mid-ticket / programa o coaching $1.000+ / procedimiento médico/estético / servicio B2B custom / high-ticket >$5.000.
- Resultado: regla de transparencia de precio activada para Conversión.

**Paso 6 — Mapa de creencias del nicho (sección N del brief):**
- Mitos populares, verdades incómodas, prácticas saturadas, enfoques con los que NO está de acuerdo.
- Si va a usar Polarización en modo sostenido: tesis central definida.
- Resultado: combustible para Polarización guardado.

**Sin estos 6 pasos completados, la skill se niega a generar contenido — devuelve mensaje pidiendo completar el paso faltante.**

### 22.2 Mantenimiento del brief

- Revisión completa cada 6 meses.
- Banco de Auto-Aplicación: agregar nuevos momentos cada vez que ocurran (mínimo 1 al mes).
- Mapa de Dolores: refinar cuando el usuario reciba comentarios o DMs que revelen dolores no mapeados.

## 23. CTAs permitidos por tipo de contenido

| Tipo | CTAs permitidos | CTAs prohibidos |
|---|---|---|
| **Relacionamiento** | Pregunta abierta, etiquetar a alguien, "¿te pasa?" | CTA de venta directa |
| **Engagement** | Comentar, votar, etiquetar, "te identificaste?" | CTA pesado, "síguenos para más" |
| **Polarización** | Filtro de audiencia, "sígueme si…", "comenta tu postura" | Insulto, agresión personal |
| **Transformación** | Guarda, aplica, comparte resultado, lead magnet por DM, filtrante de seguidor, etiquetar | Cualquier mención de precio o producto pago |
| **Interacción 1×1** | Pregunta concreta, caja de preguntas, respuesta a comentarios | Compartir DM sin permiso |
| **Niveles de Consciencia** | Por nivel: explorar, aplicar, comparar, agendar llamada | Saltar el nivel del lector |
| **Autoridad** | Descarga de recurso premium, suscripción, conversación 1×1 | Venta directa con precio |
| **Conversión** | Aplicar, agendar, comprar, completar formulario | Múltiples CTAs en una pieza |

### 23.1 CTA filtrante (técnica avanzada)

En posts de alto alcance (Engagement, Polarización, Transformación), usar:

❌ Genérico: *"Síguenos para más contenido"*
✅ Filtrante: *"Sígueme si eres [perfil específico] y quieres [resultado específico]"*

Conversión de no-seguidor:
- Genérico: 0.5–1%
- Filtrante: 3–6%

### 23.2 CTA de lead magnet por DM (técnica de Transformación)

> *"Comenta '[palabra clave]' y te envío [plantilla / checklist / PDF / video extendido] por DM."*

Es probablemente el CTA más rentable del método. Convierte un post en operación de construcción de lista sin venta directa.

## 24. Reglas de transparencia de precio (consolidadas)

| Tipo de oferta | Mostrar precio en contenido |
|---|---|
| Productos físicos | Siempre |
| Productos digitales / cursos < $300 USD | Siempre |
| Productos digitales $300–$1.000 | Depende de posicionamiento |
| Programas, coaching, mentoría $1.000+ | **No mostrar.** Aplicación / llamada |
| Procedimientos médicos / estéticos | **No mostrar.** Consulta de valoración |
| Servicios B2B custom | **No mostrar.** Llamada |
| High-ticket > $5.000 | **Nunca mostrar.** Aplicación obligatoria |

**Principio:** el precio sin contexto provoca rechazo automático. En high-ticket, lo correcto es no entregarlo hasta que haya calificación que valide encaje.

## 25. Reglas de seguridad transversales

Independiente del tipo de contenido, la skill no genera ni recomienda:

1. **Contenido que ataque a personas, grupos vulnerables o protegidos.** Polarización es contra prácticas, mitos, tendencias — nunca contra personas o categorías protegidas.
2. **Contenido sobre temas no relacionados con el nicho.** Política partidista, religión, identidad de género, conflictos geopolíticos no son terreno del método.
3. **Promesas absolutas sin condiciones.** *"Te aseguro que vas a [resultado] en [tiempo]"* sin disclaimers, en ningún tipo de contenido.
4. **Falsa urgencia o escasez.** En Conversión, los números deben ser reales.
5. **Casos de cliente sin permiso.** En Autoridad y Conversión.
6. **Contenido que sexualice o que sea inapropiado para el nicho.**
7. **Compartir DMs privados sin permiso.** En Interacción 1×1.
8. **Generación de contenido que el usuario claramente está usando para manipular** (ej. seducción que cruce a manipulación, marketing engañoso, productos sin sustento).

Si el usuario pide algo que viola alguna de estas reglas, la skill explica el conflicto, ofrece alternativa éticamente alineada y, si el usuario insiste, declina.

## 26. Errores comunes globales

Independiente del tipo de contenido:

1. **Producir desde un brief incompleto.** El brief sin Banco de Auto-Aplicación o sin Mapa de Dolores produce contenido genérico.
2. **Repetir el mismo gancho 5 veces seguidas.** El método tiene 20 ganchos por tipo. Hay que rotar.
3. **No identificar el nivel de consciencia del lector.** Hablarle a Unaware con copy de Most Aware = invisibilidad.
4. **Saturar de un solo tipo.** 5 piezas seguidas de Conversión queman lista. 5 seguidas de Engagement no construyen marca.
5. **No medir.** Las métricas blandas se sienten; las duras se cuentan. Ambas importan.
6. **Copiar literalmente plantillas sin adaptación al contexto.** Las plantillas son punto de partida, no finalidad.
7. **Producir sin revisar contra los errores comunes del tipo específico.**
8. **No actualizar el brief.** Brief de hace 18 meses produce contenido desconectado del presente del creador.
9. **Pedir a la skill contenido sin definir tipo.** *"Hazme un post"* es input débil. *"Hazme un post de Niveles de Consciencia para Solution Aware con sub-categoría comparativa"* es input fuerte.
10. **Mezclar 2 o más tipos en una sola pieza.** El método organiza por tipos porque cada uno tiene mecánica propia. Mezclarlos produce piezas que no logran el objetivo de ninguno.

---
