# Fundamentos del Método REPTINAC

*Filosofía, los 8 tipos de un vistazo, cómo se relacionan, cómo se usa.*

---

# PARTE I — FUNDAMENTOS

## 1. Qué es el Método REPTINAC

REPTINAC es un sistema de creación de contenido estructurado para marcas personales, negocios e infoproductos que organiza la producción editorial en **8 tipos de contenido complementarios**, cada uno con un propósito específico dentro del embudo de marketing y del recorrido mental del prospecto.

El nombre es acrónimo de los 8 tipos:

- **R**elacionamiento
- **E**ngagement
- **P**olarización
- **T**ransformación
- **I**nteracción 1×1
- **N**iveles de Consciencia
- **A**utoridad
- **C**onversión

Cada tipo tiene mecánicas, reglas, ganchos, plantillas y métricas propias. Una marca saludable rota entre los 8 según su etapa, su nicho y su momento comercial. Una marca que solo ejecuta 2 o 3 de los tipos tiene el alcance y la conversión que esa simplificación permite — generalmente, mucho menores que su potencial.

## 2. Filosofía y diferenciales

REPTINAC se construye sobre 5 principios que lo diferencian de los enfoques genéricos de "calendario de contenido":

**1. La audiencia no es uniforme.** No todos los seguidores están en la misma etapa mental. Lo que vende a uno aburre a otro. Por eso REPTINAC distribuye contenido para los 5 niveles de consciencia simultáneamente (Eugene Schwartz).

**2. La conexión emocional precede a la venta.** Sin Relacionamiento previo, todo el resto del método produce contenido frío. Sin Banco de Auto-Aplicación documentado, Relacionamiento es genérico.

**3. Los dolores específicos venden; los dolores genéricos no.** El Mapa de Dolores en 4 niveles (externo, interno, relacional, filosófico) es input estructural — sin él, el método produce contenido sin filo.

**4. El método respeta la madurez de cada audiencia.** Hablarle a un Unaware con copy de Most Aware es invisibilizar tu mensaje. REPTINAC tipifica el contenido por nivel de consciencia.

**5. Polarización y Conversión tienen reglas estrictas.** Mal ejecutadas, dañan marca por años. El método incluye protocolos no negociables para ambas.

Lo que NO es REPTINAC:
- No es una fórmula mágica que reemplaza criterio.
- No es un calendario rígido con porcentajes universales — los porcentajes son matriciales según tipo de negocio y etapa.
- No es contenido para alcance algorítmico solamente; es contenido para construir activos de marca de largo plazo.

## 3. Las 8 categorías de un vistazo

| Tipo | Propósito | Ubicación en embudo | % típico del calendario |
|---|---|---|---|
| **Relacionamiento** | Construir conexión emocional y confianza | TOFU/MOFU | 15–20% |
| **Engagement** | Atraer alcance bruto y activar el algoritmo | TOFU | 20–30% |
| **Polarización** | Diferenciar mediante postura confrontacional | MOFU | 5–10% |
| **Transformación** | Enseñar habilidades concretas que demuestran utilidad | MOFU | 20–25% |
| **Interacción 1×1** | Convertir espectadores en interlocutores activos | Transversal | 5–10% |
| **Niveles de Consciencia** | Mover al prospecto en su escalera mental hacia la compra | TOFU/MOFU/BOFU | 25–30% (distribuido por nivel) |
| **Autoridad** | Justificar el derecho a cobrar lo que cobras | MOFU/BOFU | 10–15% |
| **Conversión** | Pedir la venta de manera directa y estructurada | BOFU | 10–15% |

Estos porcentajes son referencia general para una cuenta establecida. La matriz completa por tipo de negocio aparece en la Parte IV.

## 4. Cómo se relacionan entre sí

Los 8 tipos no operan aislados — funcionan como un sistema con flujos predecibles:

**Cadenas naturales:**
- Engagement → atrae alcance → la audiencia llega a Relacionamiento.
- Relacionamiento + Autoridad → construyen confianza → habilitan Conversión.
- Polarización → filtra audiencia → la calificada queda receptiva a Niveles de Consciencia y Conversión.
- Niveles de Consciencia 5→4→3→2 → preparan al prospecto → Conversión cierra.
- Transformación + Interacción 1×1 → demuestran utilidad y receptividad → habilitan upsell o programas premium.

**Solapamientos a evitar (errores comunes):**
- Mezclar Conversión con Transformación en la misma pieza (mata las dos).
- Confundir "Valores y creencias" (Relacionamiento) con Polarización.
- Hacer Autoridad sin Relacionamiento previo (parece presumido y frío).
- Hacer Conversión sin Niveles de Consciencia previo (vende a una audiencia que no está preparada).

## 5. Cómo se usa este método

REPTINAC se aplica en 4 fases:

**Fase 1 — Configuración (una vez):**
El usuario llena el Brief de Marca (modo libre o estructurado), define avatar, llena el Mapa de Dolores en 4 niveles, y registra el Banco de Auto-Aplicación con mínimo 8 momentos. Ver Parte II.

**Fase 2 — Selección de tipo:**
Para cada pieza de contenido, el usuario (o la skill) decide cuál de los 8 tipos generar. Esta decisión depende de:
- Etapa de cuenta (cuenta nueva / establecida / lanzamiento activo)
- Tipo de negocio (matriz de proporciones, ver Parte IV)
- Distribución de los últimos 14 días (evitar repetir el mismo tipo)
- Calendario estacional (fechas especiales modulan)

**Fase 3 — Generación de pieza:**
Aplicando el capítulo correspondiente (Parte III), se construye la pieza con su estructura específica — anatomía, ganchos, plantilla de caption, CTA permitido para ese tipo.

**Fase 4 — Validación:**
Antes de publicar, la pieza pasa el checklist del tipo (errores comunes a evitar) y la regla transversal (Parte V).

---
