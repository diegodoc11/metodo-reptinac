# Anexo B — Calendario de Fechas Especiales por País

*Fechas relevantes para Colombia, México, España y fechas universales del calendario digital. Reglas de uso por nicho.*

---

## ANEXO B — Calendario de fechas especiales por país

### Colombia

**Enero:** Año Nuevo (1), Reyes Magos (6), Día del Periodista (4)
**Febrero:** Día Internacional contra el Cáncer (4), San Valentín (14), Día de la Mujer Hispana (12)
**Marzo:** Día Internacional de la Mujer (8), Día del Padre (19, católico), Día Mundial del Sueño (3er viernes)
**Abril:** Día del Idioma (23), Semana Santa (variable)
**Mayo:** Día del Trabajo (1), Día de la Madre (2do domingo), Día del Maestro (15)
**Junio:** Día del Padre (3er domingo), Día Mundial del Medio Ambiente (5), Sagrado Corazón (variable)
**Julio:** Día de la Independencia (20), Batalla de Boyacá (7 agosto)
**Agosto:** Asunción (15), Día del Empresario Colombiano (3er viernes)
**Septiembre:** Amor y Amistad (3er sábado), Día Internacional de la Belleza (9), Día del Estudiante (22)
**Octubre:** Día de la Raza/Diversidad Cultural (12), Día Mundial de la Salud Mental (10)
**Noviembre:** Día de Todos los Santos (1), Independencia de Cartagena (11), Black Friday (4to viernes), Cyber Monday (lunes siguiente)
**Diciembre:** Día de las Velitas (7), Navidad (24–25), Año Nuevo (31)

### México

**Enero:** Año Nuevo (1), Día de Reyes (6), Día del Compositor (15)
**Febrero:** Día de la Constitución (1er lunes), San Valentín (14), Día de la Bandera (24)
**Marzo:** Natalicio Benito Juárez (3er lunes), Día Internacional de la Mujer (8)
**Abril:** Día del Niño (30), Semana Santa (variable)
**Mayo:** Día del Trabajo (1), Batalla de Puebla (5), Día de la Madre (10), Día del Maestro (15)
**Junio:** Día del Padre (3er domingo), Día del Medio Ambiente (5)
**Julio:** Aniversario del Grito (no oficial, ver septiembre)
**Agosto:** Día Internacional de la Juventud (12)
**Septiembre:** Independencia (15–16), Día Internacional de la Belleza (9), Amor y Amistad (varía)
**Octubre:** Día de la Raza (12), Día del Médico (23), Halloween (31)
**Noviembre:** Día de Muertos (1–2), Revolución Mexicana (3er lunes), Black Friday/Buen Fin (3er fin de semana)
**Diciembre:** Virgen de Guadalupe (12), Posadas (16–24), Navidad (25), Año Nuevo (31)

### España

**Enero:** Año Nuevo (1), Reyes Magos (6)
**Febrero:** Día de Andalucía (28), San Valentín (14)
**Marzo:** Día Internacional de la Mujer (8), Día del Padre (19), Semana Santa (variable)
**Abril:** Día del Libro (23), Día Mundial de la Salud (7)
**Mayo:** Día del Trabajo (1), Día de la Madre (1er domingo), Día de Europa (9), San Isidro (15)
**Junio:** Día del Padre (alternativo, varía)
**Julio:** Sant Jordi (versión catalana, 23 abril)
**Agosto:** Asunción (15)
**Septiembre:** Día Internacional de la Belleza (9), Día Mundial del Alzheimer (21)
**Octubre:** Fiesta Nacional (12), Día Mundial de la Salud Mental (10), Halloween (31)
**Noviembre:** Día de Todos los Santos (1), Black Friday (4to viernes), Cyber Monday
**Diciembre:** Constitución (6), Inmaculada (8), Navidad (25), Día de los Inocentes (28), Nochevieja (31)

### Fechas universales del calendario digital (todos los países)

- **Día de Internet:** 17 mayo
- **Día Mundial del Marketing:** 27 abril
- **Día del SEO:** 1 julio
- **Día Mundial de las Redes Sociales:** 30 junio
- **Singles' Day (11.11):** 11 noviembre — origen China, ahora global
- **Día Mundial sin Wifi:** 8 julio
- **Día Internacional del Programador:** 13 septiembre

### Reglas de uso en el calendario REPTINAC

- Una doctora estética usa: Día Internacional de la Belleza, Día de la Madre, Día Mundial del Sueño, Día Mundial de la Salud Mental, Día de la Mujer.
- Un especialista en marketing con IA usa: Día de Internet, Día Mundial del Marketing, Singles' Day, Día Internacional del Programador.
- Un agencia de marketing digital usa: Día de Internet, Día Mundial del Marketing, Día del SEO, Black Friday, Cyber Monday.
- Un coach de habilidades sociales usa: Día Internacional de la Mujer, Día Mundial de la Salud Mental, Día del Hombre Soltero (no usar Singles' Day comercial), Día Internacional de la Amistad.

---
