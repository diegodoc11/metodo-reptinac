# Tipo 1 — RELACIONAMIENTO

*Conexión emocional y confianza. Cuándo, sub-categorías, anatomía, 20 ganchos, plantilla, 4 ejemplos en nichos, KPIs, errores, cadencia.*

---

## 11. RELACIONAMIENTO

### 11.1 Propósito

Relacionamiento es el tipo de contenido que construye **confianza emocional antes de la venta**. Mientras la competencia muestra catálogos, beneficios y promociones, este tipo muestra a una persona real con historia, valores, contradicciones y propósito específico. Su trabajo no es educar (eso es Transformación) ni demostrar autoridad (eso es Autoridad): es lograr que la audiencia sienta que conoce al creador — y que, cuando llegue el momento de comprar, esa decisión se sienta como elegir a alguien cercano, no contratar a un desconocido.

En 2026, con la saturación de contenido producido por IA, Relacionamiento es uno de los pocos moats reales que le quedan a una marca personal o negocio. Es activo de largo plazo, no truco de alcance.

### 11.2 Cuándo usarlo en el embudo

- **Top of funnel:** primer punto de contacto humano.
- **Middle of funnel:** mantiene caliente al lead que aún no compra.
- **Bottom of funnel:** justo antes de una conversión, cierra brechas emocionales que el contenido de venta no puede tocar.

**Cadencia:** entre 15% y 20% del calendario en la mayoría de casos. Hasta 25% para creadores de contenido cuya marca personal ES el producto.

### 11.3 Las 6 sub-categorías de Relacionamiento

1. **Origen** — cómo y por qué empezaste. Máximo 1–2 veces al trimestre. Una buena historia de origen vale 50 posts genéricos.
2. **Tras bambalinas (BTS)** — proceso actual, herramientas, rituales, día a día. La sub-categoría más frecuente.
3. **Vulnerabilidad presente** — lo que TE CUESTA hoy, no lo que te costó hace 5 años.
4. **Valores y creencias** — lo que defiendes y lo que rechazas en posiciones controvertidas de la industria.
5. **Momentos pivote** — el día específico, la conversación, la decisión que cambió algo.
6. **Tribu** — equipo, mentores, clientes con nombre y cara, comunidad.

### 11.4 Qué compartir (matriz)

| Sub-categoría | Incluir | Evitar |
|---|---|---|
| Origen | Año, lugar, contexto sensorial; momento exacto del "clic"; qué creías antes/qué crees ahora | "Siempre supe que…", arcos lineales sin fricción |
| BTS | Detalles concretos (herramienta X, hora Y, problema Z); imperfección visible | Día perfecto, rutina aspiracional sin grietas |
| Vulnerabilidad presente | Miedo o reto exacto de esta semana; cómo lo estás manejando ahora | Vulnerabilidad ya resuelta empacada como si fuera presente |
| Valores y creencias | Postura clara con la que alguien podría no estar de acuerdo | "Creo en la excelencia y el trabajo duro" |
| Momentos pivote | Fecha, lugar, frase exacta dicha o escuchada, qué cambió después | "Un día me di cuenta de que…" sin anclajes |
| Tribu | Nombres reales, fotos, qué aportan ELLOS específicamente | Agradecimientos genéricos a "mi increíble equipo" |

### 11.5 Anatomía de un post de Relacionamiento

**Movimiento 1 — Anclaje (0–3 segundos):** detalle específico, momento, contradicción. NO frase motivacional. NO dato. Anclaje sensorial o emocional concreto.
- ❌ "Hoy quiero contarles algo importante"
- ✅ "Eran las 3:47 AM y yo estaba mirando el techo, sin haber facturado un peso en 6 semanas."

**Movimiento 2 — Tensión:** qué estaba en juego. Por qué importaba. Qué dolía o asustaba.

**Movimiento 3 — Pivote o insight:** qué cambió, qué aprendiste, qué decidiste. Aquí aparece tu visión del mundo.

**Movimiento 4 — Puente al lector:** ¿por qué esto le importa al que lee? Frase que conecta tu historia con su realidad. NO CTA de venta. Puente humano.

**CTA suave opcional al final:** pregunta abierta o invitación a compartir su versión.

### 11.6 Biblioteca de ganchos (20 plantillas transferibles)

1. "Eran las [hora específica] y yo [acción concreta vulnerable]…"
2. "No te he contado esto antes, pero hace [tiempo]…"
3. "Hace [X años] yo era exactamente la persona que hoy tengo como cliente."
4. "Si alguien me hubiera dicho hace [X] que hoy estaría [haciendo X], le habría dicho que estaba loco."
5. "Esta foto es de [fecha]. Lo que no se ve es lo que estaba pasando ese día."
6. "Casi renuncio [hace X tiempo]. Esto es lo que me hizo quedarme."
7. "Llevo [X años] haciendo esto y todavía [admisión humana presente]."
8. "Mi primer [intento/cliente/proyecto] fue un fracaso. Te cuento por qué fue lo mejor que me pasó."
9. "Hay un detalle de mi historia que cambia todo lo que crees saber de mí."
10. "Lo más difícil de mi trabajo no es lo que la gente cree."
11. "Hoy [verbo] algo que normalmente no muestro."
12. "Mi [mentor/profesor/madre] me dijo una frase que llevo [X años] sin poder olvidar."
13. "El día que casi tiro la toalla."
14. "Hace [X] hice algo de lo que todavía me cuesta hablar."
15. "[Nombre real] me cambió la vida con una frase de 6 palabras."
16. "Hoy cumplo [X tiempo] de haber tomado la decisión más rara de mi vida."
17. "Te voy a mostrar el lado feo de [tu trabajo/proceso]."
18. "Hay una pregunta que me hacen cada semana y nunca había respondido en serio."
19. "Antes de que me sigas pensando que tengo todo resuelto, mira esto."
20. "Esto es lo que estaba pasando en mi vida cuando publiqué [post conocido tuyo]."

### 11.7 Plantilla de caption rellenable

```
[ANCLAJE — un momento específico, sensorial, una línea]

[CONTEXTO — 2-3 líneas: dónde estabas, cuándo, qué pasaba alrededor]

[TENSIÓN — 2-3 líneas: qué estaba en juego, qué dolía, qué temías]

[PIVOTE / INSIGHT — 2-4 líneas: qué cambió, qué aprendiste, qué decidiste]

[PUENTE AL LECTOR — 1-2 líneas: por qué esto le importa a quien lee]

[CTA SUAVE OPCIONAL — pregunta abierta o invitación]
```

Reglas: máximo 150 palabras para Reels y feed. En carrusel hasta 250.

### 11.8 Ejemplos completos

**Ejemplo 1 — Belleza/medicina estética (Momento pivote, Reel 30s)**

Gancho: *"El día que mi mamá lloró cuando le dije que iba a estudiar medicina estética."*

> Era diciembre de 2017. Le dije a mi mamá que después de 6 años de medicina general iba a especializarme en estética.
>
> Lloró. No de orgullo. De decepción. *"Mija, eso no es medicina de verdad."*
>
> Yo sabía por qué lo decía. En su cabeza, "doctora" era urgencias, hospital, vidas salvadas. Estética sonaba a vanidad.
>
> Lo que no le podía explicar todavía: que el primer paciente al que le quitas una cicatriz que llevaba 20 años escondiendo, también es una vida que cambia.
>
> Hace 3 meses mi mamá vino a la clínica por primera vez. Se hizo un tratamiento. Lloró otra vez. Esta vez no de decepción.
>
> A veces la gente que más nos ama es la última en entender lo que hacemos. Y está bien.
>
> ¿Tú también tomaste una decisión profesional que tu familia no entendió al principio?

**Ejemplo 2 — Marketing con IA (Vulnerabilidad presente, Reel 45s)**

Gancho: *"Llevo dos años enseñando a usar IA para marketing. Y esta semana me dio miedo lo que vi."*

> Hace dos años, cuando empecé a meterme con IA, mi promesa era simple: te enseño a ahorrar tiempo, vender más, automatizar lo aburrido.
>
> Esta semana revisé el último flujo que monté para un cliente. El sistema escribe los anuncios, segmenta, analiza el rendimiento y me sugiere los próximos pasos. Yo solo doy clic en "aprobar".
>
> Y por primera vez pensé: ¿en qué momento me volví el cuello de botella de mi propio sistema?
>
> No estoy diciendo que la IA me vaya a reemplazar. Estoy diciendo algo más incómodo: mi trabajo está cambiando más rápido de lo que estoy procesando.
>
> Te lo digo porque sé que no soy el único. Si tú también estás usando IA todos los días pero a veces te asusta lo bien que funciona — bienvenido al club.
>
> ¿A ti te ha pasado?

**Ejemplo 3 — Marketing digital (Valores controvertidos, Carrusel 7 slides)**

Slide 1: *"Perdí un cliente de $80,000 al mes por no callarme."*

Slide 2: *En enero firmé con una marca de cosmética que llevaba 8 meses sin crecer. Su problema no era el marketing. Era el producto. La fórmula no servía.*

Slide 3: *En la primera reunión de estrategia se los dije con esas palabras. No con eufemismos. No con "oportunidades de mejora".*

Slide 4: *El CMO se rió incómodo. La fundadora me miró fijo. Cinco días después llegó el email: "Decidimos no avanzar con la propuesta."*

Slide 5: *Mi socia me preguntó si valía la pena perder $80K al mes por una opinión. Le dije que sí. Llevamos años construyendo una agencia que dice lo que ve. Si empezamos a callar por dinero, ¿qué somos?*

Slide 6: *A los 3 meses, esa misma fundadora me escribió. Reformulación de producto en marcha. "Tenías razón. ¿Podemos retomar la conversación?"*

Slide 7: *Los clientes que más respeto tienen por mi trabajo son los que alguna vez les dije algo que no querían oír. Si tu agencia te está diciendo solo lo que te gusta escuchar, te están cobrando por hacerte sentir bien, no por hacerte crecer.*

**Ejemplo 4 — Coaching habilidades sociales (Origen + Valores, Reel 60s)**

Gancho: *"Pasé un año entero sin salir con nadie. A propósito. Y fue lo mejor que hice por mi vida amorosa."*

> Tenía 27 años. Llevaba 5 saliendo con mujeres y siempre terminaba igual: 3 semanas, 2 meses si tenía suerte, y luego algo se rompía sin que yo entendiera por qué.
>
> Probé los podcasts. Los libros. Las "técnicas". Funcionaba para el primer encuentro y se caía a pedazos en el tercero.
>
> Un martes cualquiera me di cuenta de algo incómodo: el problema no era cómo estaba conociendo mujeres. Era quién era yo cuando las conocía. Vacío de hobbies. Sin amigos cercanos. Esperando que alguien apareciera y le diera sentido a todo.
>
> Tomé una decisión rara: un año sin citas. Ese año no me dediqué a "trabajar mi atractivo". Me dediqué a construir una vida que me gustara aunque no llegara nadie. Aprendí guitarra mal. Hice amigos hombres reales. Subí mi nivel físico.
>
> Cuando volví a salir con alguien, ya no estaba pidiendo que me salvara. Estaba ofreciendo algo. Esa relación lleva 4 años.
>
> Lo que enseño no son técnicas para atraer mujeres. Es cómo construir el tipo de vida del que las personas quieren formar parte.
>
> ¿Cuánto tiempo llevas trabajando "tu juego" sin trabajar tu vida?

### 11.9 KPIs y métricas

**Métricas duras:**
- Comentarios cualitativos (>10 palabras): 1 cada 200 alcance
- Compartidos a stories: 1 cada 500 alcance
- Tiempo de visualización en Reels ≥75%, retención en carrusel ≥60% al último slide
- DMs cualitativos posteriores
- Tasa de saved: 1.5x el promedio del perfil

**Métricas blandas:**
- "Siento que te conozco" en DMs
- Citas de tus posts en contenidos de otros creadores
- Reducción de objeción "no te conozco lo suficiente" en llamadas de venta

### 11.10 Errores comunes a evitar

1. Vulnerabilidad performativa
2. Origen sin presente
3. Vender en el mismo post
4. Generalidad anestesiante
5. Solo highlight reel
6. Tono inconsistente entre sub-categorías
7. Hablar solo de ti sin puente al lector
8. Vulnerabilidad sin aprendizaje
9. Confundir Relacionamiento con autopromoción
10. Usar IA para escribirlo en piloto automático
11. No volver a las mismas historias

### 11.11 Cadencia recomendada

- 1–2 posts por semana, 15–20% del calendario total
- Distribución sugerida en 4 semanas:
  - Semana 1: BTS + Valores
  - Semana 2: Vulnerabilidad presente + Tribu
  - Semana 3: Momento pivote + BTS
  - Semana 4: Origen (1 al mes máximo) + Valores
- Hora ideal: 19:00–22:00 hora local
- Formato dominante: Reel a cámara > carrusel narrativo > foto + caption largo > Stories

---
