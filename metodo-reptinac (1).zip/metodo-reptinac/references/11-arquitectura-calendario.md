# Arquitectura de Calendario Editorial

*Matriz de proporciones por 5 tipos de negocio. Modificadores por etapa de cuenta y por lanzamiento activo. Calendario de fechas especiales como capa transversal.*

---

# PARTE IV — ARQUITECTURA DE CALENDARIO

## 19. Matriz de proporciones por tipo de negocio

Los porcentajes generales de la Parte I son referencia. La distribución real depende del **tipo de negocio**. La tabla matricial:

### 19.1 Marca personal high-ticket (coaching, mentoría, consultoría premium $1.000+)

| Tipo | % del calendario |
|---|---|
| Relacionamiento | 20–25% |
| Engagement | 15–20% |
| Polarización | 5–10% |
| Transformación | 20–25% |
| Interacción 1×1 | 5–10% |
| Niveles de Consciencia | 20–25% |
| Autoridad | 15–20% |
| Conversión | 5–10% |

**Lógica:** la marca ES el producto. Relacionamiento + Autoridad pesan más. Conversión es baja porque cada lanzamiento es selectivo.

### 19.2 Negocio local de servicio (clínica estética, salón, restaurante, spa)

| Tipo | % del calendario |
|---|---|
| Relacionamiento | 15–20% |
| Engagement | 25–30% |
| Polarización | 3–5% |
| Transformación | 15–20% |
| Interacción 1×1 | 10–15% |
| Niveles de Consciencia | 15–20% |
| Autoridad | 10–15% |
| Conversión | 10–15% |

**Lógica:** el alcance local importa (Engagement alto). Interacción 1×1 alta porque el cliente prefiere conversación directa antes de visitar.

### 19.3 E-commerce / producto físico

| Tipo | % del calendario |
|---|---|
| Relacionamiento | 10–15% |
| Engagement | 30–35% |
| Polarización | 3–5% |
| Transformación | 10–15% |
| Interacción 1×1 | 5–10% |
| Niveles de Consciencia | 15–20% |
| Autoridad | 5–10% |
| Conversión | 15–20% |

**Lógica:** ciclo de venta corto. Engagement alto para alcance. Conversión alta porque el producto se compra en 1–3 sesiones.

### 19.4 B2B / agencia / SaaS

| Tipo | % del calendario |
|---|---|
| Relacionamiento | 15–20% |
| Engagement | 10–15% |
| Polarización | 10–15% |
| Transformación | 25–30% |
| Interacción 1×1 | 5–10% |
| Niveles de Consciencia | 15–20% |
| Autoridad | 15–20% |
| Conversión | 5–10% |

**Lógica:** ciclo de venta largo. Transformación + Autoridad construyen credibilidad técnica. Polarización diferencia en mercado saturado. Engagement bajo porque la audiencia es más nicho.

### 19.5 Creador de contenido / infoproducto

| Tipo | % del calendario |
|---|---|
| Relacionamiento | 20–25% |
| Engagement | 25–30% |
| Polarización | 5–10% |
| Transformación | 20–25% |
| Interacción 1×1 | 10–15% |
| Niveles de Consciencia | 10–15% |
| Autoridad | 5–10% |
| Conversión | 5–10% |

**Lógica:** la marca personal es el activo. Relacionamiento + Engagement + Transformación son el corazón. Conversión solo en lanzamientos.

## 20. Modificadores por etapa de cuenta

Los porcentajes anteriores son para **cuentas establecidas (>50K seguidores, ≥18 meses de actividad)**. Cuentas en otras etapas modifican:

### 20.1 Cuenta nueva (<10K seguidores, primeros 6 meses)

- Engagement: +10% (necesitas alcance)
- Autoridad: -5% (todavía no tienes mucho que mostrar)
- Conversión: -5% (sin audiencia caliente, vender es predicar al viento)
- Polarización: -3% (mejor primero construir reputación)
- Resto: ajustar proporcionalmente

### 20.2 Cuenta en crecimiento (10K–50K seguidores, 6–18 meses)

Aplicar la matriz base sin modificadores significativos.

### 20.3 Cuenta establecida (>50K seguidores, >18 meses)

Aplicar la matriz base. Subir Autoridad si vas a justificar precios premium o entrar a tier alto.

### 20.4 Cuenta en lanzamiento activo (2–3 semanas pre + lanzamiento)

**Semana -3 (calentamiento profundo):**
- Niveles 4–3 (Problem Aware → Solution Aware): 35–40%
- Relacionamiento: 20%
- Polarización: 5–10%
- Resto: 25–30%

**Semana -2 (apuntar el cañón):**
- Niveles 2 (Product Aware): 25%
- Autoridad: 25%
- Transformación: 20%
- Relacionamiento: 15%
- Resto: 15%

**Semana -1 (apertura inminente):**
- Niveles 2: 20%
- Autoridad: 20%
- Conversión: 30%
- Relacionamiento: 15%
- Resto: 15%

**Semana 0 (lanzamiento activo):**
- Conversión: 40%
- Niveles 2: 20%
- Autoridad (testimonios): 20%
- Interacción 1×1: 15%
- Resto: 5%

## 21. Calendario de fechas especiales (capa transversal)

El calendario de fechas especiales **NO es un tipo de contenido aparte**. Es una capa que modula los 8 tipos existentes según fechas relevantes. La regla es: cualquier fecha se aprovecha si conecta orgánicamente con tu nicho — y se ignora si no.

### 21.1 Categorías de fechas

1. **Fechas universales con potencial comercial:**
   - Inicios de mes/semestre/año
   - Cierres de trimestre
   - Día de la madre, padre, amistad, mujer
   - Día del idioma, lectura, salud mental
   - Black Friday, Cyber Monday
   - Navidad, Año Nuevo, Reyes

2. **Fechas específicas del nicho:**
   - Día Internacional de la Belleza (sept 9)
   - Día Mundial de la Salud Mental (oct 10)
   - Día del Emprendedor (varía por país)
   - Día Internacional contra el Cáncer (feb 4)
   - Día Mundial del Sueño (marzo)

3. **Fechas culturales locales:**
   - Por país (Colombia, México, España, etc.)
   - Por región o ciudad
   - Festividades religiosas locales

4. **Hitos de tu negocio:**
   - Aniversario de tu marca
   - Cumpleaños tuyo
   - Aniversario de tu primer cliente
   - Cierre de cohorte anterior

### 21.2 Reglas de uso

1. **Solo si conecta con tu nicho.** Una doctora estética no necesita publicar el día del programador.
2. **Aprovechar 60–70% de las fechas universales relevantes** y 90–100% de las específicas del nicho.
3. **Día especial = 1 pieza, no más.** No saturar.
4. **Conectar la fecha con un tipo de contenido específico.** Día de la madre puede ser Relacionamiento (historia con tu mamá), Niveles de Consciencia (problema típico de mujeres en esa etapa), o Conversión (oferta especial).
5. **NO usar fechas trágicas o de duelo nacional para vender.**

Calendario completo por país en Anexo B.

---
