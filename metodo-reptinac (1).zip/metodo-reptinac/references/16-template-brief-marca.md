# Anexo A — Template del Brief de Marca

*Plantillas listas para llenar en modo libre y modo estructurado (15 secciones).*

---

## ANEXO A — Template Brief de Marca

### Modo libre

> *"Cuéntame tu historia como si me la estuvieras contando a un amigo en un café. Empieza desde antes de meterte en este nicho. Habla de los momentos clave, los fracasos, las veces que tu propio producto te salvó, las personas que te aportaron, las cosas con las que estás en desacuerdo en tu industria. Sin orden. Sin filtro. Habla todo lo que quieras."*

Después del relato libre, la skill ejecuta preguntas puntuales para llenar huecos:
- *"Mencionaste que cambiaste de carrera por X. ¿Recuerdas la fecha exacta?"*
- *"No me hablaste del Banco de Auto-Aplicación. ¿Me das 5–8 momentos donde lo que vendes te ayudó a ti?"*
- *"¿Cuál es la práctica de tu industria con la que más estás en desacuerdo?"*
- *"¿Tu cliente ideal cómo se llama, qué edad tiene, dónde vive?"*

### Modo estructurado

**A. Identidad core**
- Nombre completo:
- Edad:
- Ubicación (ciudad, país):
- Profesión específica:
- Nicho exacto:
- Productos/servicios principales:
- Rango de precios:

**B. Tipo de negocio y nicho**
- Tipo (5 opciones de sección 19):
- Nivel de competencia: alto / medio / bajo
- Etapa de cuenta: nueva / crecimiento / establecida / lanzamiento

**C. Cliente ideal específico**
- Edad:
- Género:
- Ubicación:
- Profesión o etapa de vida:
- Nivel socioeconómico:
- Estado emocional típico cuando llega a ti:

**D. Viaje del héroe**
1. Vida ordinaria antes del nicho (edad, contexto):
2. Llamado a la aventura (cómo descubriste la oportunidad):
3. Resistencia o dudas iniciales:
4. Catalizador (persona, evento, decisión):
5. Cruce del umbral (fecha y momento):
6. 3 errores grandes del camino:
7. Crisis profunda (el momento más oscuro):
8. Transformación interna:
9. Lo que hoy ofreces:

**E. Banco de momentos pivote** (3+)
- Momento 1: fecha, lugar, frase exacta, qué cambió después
- Momento 2: ...
- Momento 3: ...

**F. Banco de fracasos con aprendizaje** (3+)
- Fracaso 1: contexto, qué pasó, qué aprendiste
- ...

**G. Banco de victorias inesperadas o emotivas** (3+)
- Victoria 1: ...

**H. Banco de Auto-Aplicación** (8+)
- Momento 1:
  - Cuándo y dónde:
  - Situación enfrentada:
  - Herramienta/técnica/principio aplicado:
  - Cómo te fue:
  - Qué le diría a un cliente que duda:
- Momento 2: ...
- (mínimo 8)

**I. Posturas y valores**
- 3 cosas que defiendes en tu industria:
- 3 cosas con las que NO estás de acuerdo:
- 3 frases que repites en privado:

**J. Tribu**
- Mentores reales (nombre + qué te aportó cada uno):
- Equipo / socios:
- Clientes con permiso para mencionar:
- Comunidad o grupo de pertenencia:

**K. BTS / vida cotidiana**
- Rutina de trabajo:
- Herramientas que usas:
- Dónde trabajas físicamente:
- Rituales pre y post trabajo:
- Lecturas, podcasts, referentes actuales:

**L. Vulnerabilidades presentes**
- 3 cosas que aún te cuestan en tu trabajo HOY:
- 1 miedo profesional actual:
- 1 área donde sigues siendo principiante:

**M. Conexión profunda con la oferta**
- ¿Qué problema TUYO resolviste, que ahora ayudas a otros a resolver?
- ¿Cómo lo que vendes hoy fue, primero, una solución para ti?

**N. Mapa de creencias del nicho**
- 5+ mitos populares en tu nicho:
- 5+ verdades incómodas que el gremio no dice:
- 3+ prácticas saturadas o contraproducentes:
- 3+ enfoques de figuras conocidas con los que NO estás de acuerdo:
- Tesis central para Polarización sostenida (si aplica):

**O. Mapa de Dolores del Avatar**
- Nivel 1 — Externo (5+ dolores específicos):
- Nivel 2 — Interno (5+ dolores específicos):
- Nivel 3 — Relacional (5+ dolores específicos):
- Nivel 4 — Filosófico (5+ dolores que pasen el Test de Amenaza Concreta):

---
