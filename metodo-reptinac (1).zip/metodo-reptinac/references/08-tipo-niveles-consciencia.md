# Tipo 6 — NIVELES DE CONSCIENCIA

*Mover al prospecto en su escalera mental (5 niveles Schwartz). Anatomías y plantillas por nivel. Mapeo Niveles × Niveles de Dolor.*

---

## 16. NIVELES DE CONSCIENCIA

### 16.1 Propósito

Niveles de Consciencia mueve a la audiencia hacia arriba en la escalera mental hacia la compra. Cubre los 5 niveles de Eugene Schwartz (*Breakthrough Advertising*, 1966):

1. **Most Aware (Decidido)** — quiere comprar, solo necesita el empujón
2. **Product Aware (Consciente del producto)** — conoce tu producto, considera comprar
3. **Solution Aware (Consciente de la solución)** — conoce que existen soluciones, no cuál
4. **Problem Aware (Consciente del problema)** — sabe que tiene problema, no que hay solución
5. **Unaware (Inconsciente)** — no sabe que tiene problema

El problema #1 en creadores: publican el 90% del contenido para los 2–5% que ya están listos para comprar (Most Aware), dejando al 95% sin atender.

### 16.2 Distribución típica de la audiencia

| Nivel | Etapa de embudo | % típico de la audiencia |
|---|---|---|
| 5. Unaware | TOFU profundo | 30–40% |
| 4. Problem Aware | TOFU | 25–30% |
| 3. Solution Aware | MOFU | 15–20% |
| 2. Product Aware | MOFU/BOFU | 8–12% |
| 1. Most Aware | BOFU | 2–5% |

### 16.3 Distribución sugerida del calendario

| Nivel | % del contenido total |
|---|---|
| Unaware | 5–8% |
| Problem Aware | 8–12% |
| Solution Aware | 8–12% |
| Product Aware | 5–8% |
| Most Aware | 2–4% (cubierto principalmente por tipo Conversión) |

**Total Niveles de Consciencia: 25–35% del calendario.**

### 16.4 Cómo identificar el nivel de tu audiencia

**Test del comentario más frecuente:**
- *"No sabía que esto fuera un problema"* → Unaware
- *"A mí también me pasa, no sé qué hacer"* → Problem Aware
- *"He visto que existen [opciones]. ¿Cuál recomiendas?"* → Solution Aware
- *"He visto tu contenido, ¿cómo funciona específicamente lo que ofreces?"* → Product Aware
- *"¿Cómo me inscribo? ¿Cuándo abre el cupo?"* → Most Aware

Mira los últimos 30–50 comentarios y DMs. Identifica el más frecuente. Eso te dice dónde está la masa de tu audiencia.

### 16.5 Mapeo Niveles de Consciencia × Niveles de Dolor

Cada Nivel de Consciencia activa uno o más Niveles de Dolor:

| Nivel de Consciencia | Niveles de Dolor a activar |
|---|---|
| 5 — Unaware | Externo principal |
| 4 — Problem Aware | Externo + Interno |
| 3 — Solution Aware | Interno + Relacional |
| 2 — Product Aware | Los 4 niveles |
| 1 — Most Aware | Los 4 niveles (recordatorio integral) |

**Regla:** la pieza con más profundidad emocional toca al menos 2 de los 4 niveles de dolor.

### 16.6 Anatomías por nivel

**Nivel 5 (Unaware):**
1. Síntoma normalizado
2. Revelación ("eso es signo de [problema]")
3. Validación con dato o evidencia
4. Apertura empática ("no te asustes, no te estoy vendiendo nada")
5. Invitación a profundizar

**Nivel 4 (Problem Aware):**
1. Reconocimiento del dolor
2. Profundización del mecanismo
3. Causa raíz (separa síntoma de causa)
4. Existencia de salida (sin nombrar tu producto)
5. CTA exploratorio

**Nivel 3 (Solution Aware):**
1. Mapeo de opciones
2. Pros y contras de cada enfoque
3. Cuándo elegir cada uno (criterios objetivos)
4. Posicionamiento sutil del tuyo
5. CTA de aplicación

**Nivel 2 (Product Aware):**
1. Apertura específica de tu oferta
2. Diferenciación frente a alternativas
3. Resultado concreto (caso, métrica, antes/después)
4. Manejo de objeción común
5. CTA de profundización

**Nivel 1 (Most Aware):** se cubre principalmente desde el tipo Conversión.

### 16.7 Biblioteca de ganchos por nivel

**Nivel 5 — Unaware:**
1. *"Si haces [acción que parece normal], probablemente estás causándote [problema oculto]."*
2. *"El [%] de personas con [síntoma común] tiene en realidad [problema serio]."*
3. *"Lo que crees que es [explicación común] en realidad es [verdadera causa]."*
4. *"Esto que te pasa todas las semanas no es normal. Te explico."*
5. *"Hay un patrón silencioso en [población] que casi nadie nombra."*

**Nivel 4 — Problem Aware:**
6. *"Si llevas [X tiempo] con [síntoma], esta es la razón que nadie te ha explicado."*
7. *"La causa de [tu problema] casi nunca está donde la buscas."*
8. *"[Síntoma común] es la consecuencia, no el problema. El problema real es:"*
9. *"3 razones por las que [problema] no se resuelve solo."*
10. *"Lo que diferencia a quien sale de [problema] de quien se queda atrapado."*

**Nivel 3 — Solution Aware:**
11. *"Hay 3 caminos para resolver [problema]. Cada uno tiene su perfil de cliente."*
12. *"[Enfoque A] vs [enfoque B]: cuándo conviene cada uno."*
13. *"Antes de elegir entre [opciones], hazte estas 4 preguntas."*
14. *"Por qué [enfoque común] funciona para algunos y no para otros."*
15. *"Mapa de las soluciones que existen para [problema] y cuál se ajusta a ti."*

**Nivel 2 — Product Aware:**
16. *"Esto es exactamente cómo funciona mi [producto/método]. Sin tabúes."*
17. *"Lo que diferencia mi enfoque de los [N] que ya conoces."*
18. *"Cómo mis clientes pasan de [estado A] a [estado B] en [tiempo concreto]."*
19. *"Si estás considerando trabajar conmigo, esto es lo que necesitas saber primero."*
20. *"3 objeciones que me dijeron antes de comprar y cómo se resolvieron."*

### 16.8 Plantillas por nivel

**Plantilla Nivel 5:**
```
[SÍNTOMA NORMALIZADO]
[REVELACIÓN — "en realidad eso es signo de…"]
[EVIDENCIA — dato, mecanismo, ejemplo]
[APERTURA — "no te estoy vendiendo nada"]
[INVITACIÓN A SEGUIR EXPLORANDO]
```

**Plantilla Nivel 4:**
```
[RECONOCIMIENTO del dolor]
[PROFUNDIZACIÓN del mecanismo]
[CAUSA RAÍZ — separa síntoma de causa]
[EXISTE SALIDA — sin nombrar tu producto]
[CTA EXPLORATORIO]
```

**Plantilla Nivel 3:**
```
[MAPEO de opciones]
[PROS Y CONTRAS de cada una]
[CRITERIO DE DECISIÓN según perfil]
[POSICIONAMIENTO SUTIL del tuyo]
[CTA DE EVALUACIÓN]
```

**Plantilla Nivel 2:**
```
[APERTURA ESPECÍFICA de tu oferta]
[DIFERENCIACIÓN frente a alternativas]
[RESULTADO CONCRETO con caso o métrica]
[MANEJO de objeción común]
[CTA DE PROFUNDIZACIÓN]
```

### 16.9 Ejemplos completos (uno por nivel, un nicho cada uno)

**Ejemplo Nivel 5 (Unaware) — Belleza:**

Gancho: *"Si tienes 28 y empiezas a verte cansada en las fotos, no es la edad. Y no es estrés. Te explico qué es."*

> *Tu cara se ve cansada en las fotos por una combinación de 4 cosas que nadie está nombrando — y todas las haces a diario sin saberlo.*
>
> *Una: pasas más de 6 horas frente a pantallas y nunca usas protector con filtro de luz azul.*
>
> *Dos: te lavas la cara con productos para piel grasa cuando tu piel es deshidratada.*
>
> *Tres: duermes menos de 6 horas dos noches seguidas a la semana. La piel hace su reparación entre las 11 PM y las 3 AM.*
>
> *Cuatro: tomas anticonceptivos y nadie te explicó que cambian tu rutina ideal.*
>
> *No es vejez. Es daño acumulado evitable. Te lo digo no para venderte nada — te lo digo para que revises cuántas estás haciendo. Si te identificaste con 2 o más, comenta abajo. Y haré contenido detallado de cómo arreglar cada una.*

**Ejemplo Nivel 4 (Problem Aware) — Marketing con IA, Carrusel 7 slides:**

Slide 1: *"Si llevas más de 6 meses 'pensando en empezar con IA', el problema no es el tiempo."*

Slide 2: *La razón real: parálisis por análisis. Y en IA está activada por dos cosas específicas.*

Slide 3: *Causa 1: sobreoferta. Hay más de 3.000 herramientas de IA. Cada semana sale una nueva. Tu cerebro no puede elegir entre 3.000 opciones.*

Slide 4: *Causa 2: ausencia de marco mental. Tienes herramientas pero no sabes para qué problema específico aplicarlas.*

Slide 5: *Lo que te pasa por dentro: cada vez que abres ChatGPT con la idea de "explorar", terminas escribiendo dos cosas, no te emociona el resultado, cierras la pestaña.*

Slide 6: *La solución NO es: otro curso introductorio, más tutoriales, probar la herramienta de moda. Esas tres te mantienen en parálisis.*

Slide 7: *La solución SÍ es: 1) un proceso de tu negocio definido, 2) la herramienta que mejor encaje con ese proceso, 3) un workflow repetible aplicado al menos 3 veces antes de cambiarlo.*

CTA: *"Si te identificaste, comenta 'Sistema' y te envío por DM un PDF con las 3 preguntas para definir tu primer workflow."*

**Ejemplo Nivel 3 (Solution Aware) — Marketing digital, Carrusel 8 slides:**

Slide 1: *"Si llegaste al punto de necesitar ayuda con tu marketing, hay 3 caminos. Cada uno te lleva a un lugar distinto."*

Slide 2: **Camino A: Freelance** ($500–$2.500/mes). Mejor para: presupuesto limitado, dueño con tiempo, UN servicio específico. Riesgo: si se va, te quedas en cero.

Slide 3: **Camino B: Agencia generalista** ($2.500–$8.000/mes). Mejor para: negocios consolidados que necesitan ejecución amplia. Riesgo: ejecución promedio en TODO.

Slide 4: **Camino C: Agencia especializada** ($5.000–$15.000/mes). Mejor para: negocios que ya validaron y quieren crecer en UN canal. Riesgo: dependencia de un canal.

Slide 5: **Pregunta clave:** ¿En qué etapa de negocio estás?
- Validando producto: Freelance
- Crecer en UN canal: Agencia especializada
- Crecer en TODOS los canales: Agencia generalista

Slide 6: **Error frecuente:** Contratar agencia generalista cuando aún estás validando. Resultado: gastas $5.000/mes optimizando un funnel que no debería existir.

Slide 7: **Otro error:** Contratar freelance barato cuando ya facturas $50K/mes. El freelance se vuelve cuello de botella.

Slide 8: *La pregunta no es "cuál es mejor". Es "cuál encaja con tu etapa". Yo dirijo agencia especializada — te lo aclaro porque mi recomendación tiene ese sesgo. Si estás en etapa de validar, NO contrates agencia. Ni la mía ni otra.*

**Ejemplo Nivel 2 (Product Aware) — Coaching seducción, Carrusel 9 slides:**

Slide 1: *"Si has pensado en trabajar conmigo y aún no diste el paso, este post es para ti. Te respondo las 5 dudas que más me llegan en DM."*

Slide 2: **Duda 1: "¿Funciona si soy introvertido?"** *Sí. Los introvertidos suelen tener mejores resultados. Ya tienen mundo interno desarrollado. Solo les falta presencia exterior. Eso se entrena en 3–4 meses.*

Slide 3: **Duda 2: "¿Tengo que hacer 'aproximaciones en frío'?"** *No. No enseño pickup. No enseño técnicas de calle. El programa es 70% trabajo de identidad, 30% interacciones reales en contextos donde TÚ ya estás. Si quieres enfoque de calle, no soy tu coach.*

Slide 4: **Duda 3: "¿Cuánto tiempo se ve resultado?"** *Resultado interno (cómo te sientes) en 4–6 semanas. Resultado externo (citas, relaciones) entre el mes 3 y el 6. Cualquier coach que te prometa resultado externo en 30 días te está vendiendo humo.*

Slide 5: **Duda 4: "¿Cuánto cuesta?"** *El programa completo cuesta lo que cobra una buena terapia psicológica de 3 meses. La inversión exacta la vemos en la llamada de aplicación.*

Slide 6: **Duda 5: "¿Cómo sé si soy buen candidato?"** *Buen candidato:*
- *Llevas más de 1 año estancado en tu vida amorosa*
- *Has probado libros, podcasts y otros enfoques sin resultado sostenible*
- *Tienes vida profesional o de hobbies activa pero la afectiva no avanza*
- *Estás dispuesto a 4–6 horas semanales durante 4 meses*

Slide 7: **Mal candidato:**
- *Quieres resultado en 30 días*
- *Buscas técnicas para "conquistar" sin trabajar tu vida*
- *No tienes tiempo para 4 horas semanales*
- *Tu prioridad es cantidad, no profundidad*

Slide 8: **Casos reales (con permiso):**
- *Carlos, 34: 7 meses sin pareja. Después de 5 meses en el programa empezó relación que lleva 1 año.*
- *Mateo, 28: 6 años sin relación seria. Cerró programa hace 8 meses, ahora vive con su pareja.*
- *Tomás, 42: divorciado hace 3 años, miedo a salir. 4 meses de programa, ya en relación nueva.*

Slide 9: *Si ya leíste 9 slides hasta aquí, probablemente eres buen candidato. La aplicación toma 5 minutos en mi web. La llamada inicial es gratis y dura 30 minutos. Si no encajamos, te lo digo claro.*

### 16.10 KPIs y métricas

**Por nivel:**
- **Nivel 5:** alcance bruto, retención, comentarios "no sabía esto", crecimiento de seguidores nuevos
- **Nivel 4:** saves rate, comentarios cualitativos describiendo experiencia, conversión a lead magnet
- **Nivel 3:** comentarios preguntando cómo aplicar el criterio, DMs comparando opciones
- **Nivel 2:** aplicaciones a llamadas, clics al link en bio, mensajes "estoy considerando trabajar contigo"

### 16.11 Errores comunes

1. Hablarle a Unaware con copy de Most Aware (invisible)
2. Hablarle a Most Aware con contenido de Unaware (aburrido, pierde la venta)
3. Confundir Solution Aware con Product Aware
4. Saltar niveles
5. Atacar competidores en Solution Aware
6. No filtrar mal candidato en Product Aware
7. Vender en Unaware o Problem Aware (quema confianza)
8. Usar el mismo gancho para todos los niveles
9. No identificar en qué nivel está tu audiencia
10. Publicar 80% Most Aware y 20% del resto

### 16.12 Cadencia recomendada

- Distribución sugerida en una semana de 7 publicaciones:
  - 1–2 piezas Unaware
  - 1–2 piezas Problem Aware
  - 1–2 piezas Solution Aware
  - 1 pieza Product Aware
  - Most Aware se cubre desde tipo Conversión
- Pre-lanzamiento: sube Product Aware a 30–40%
- Hora ideal: Niveles 5–4 en mañana (descubrimiento); 3–2 en tarde-noche (decisión)
- Formato dominante:
  - Unaware: Reel narrativo
  - Problem Aware: Carrusel
  - Solution Aware: Carrusel comparativo
  - Product Aware: Carrusel + Reel a cámara

---
