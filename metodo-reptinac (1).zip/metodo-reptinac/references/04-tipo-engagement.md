# Tipo 2 — ENGAGEMENT

*Alcance bruto y algoritmo. Incluye Tendencias virales como sub-categoría con reglas de detección y velocidad de ejecución.*

---

## 12. ENGAGEMENT

### 12.1 Propósito

Engagement trabaja para **el algoritmo y el alcance bruto**. Mientras Relacionamiento construye conexión profunda con pocos, Engagement abre la puerta a muchos: gente que aún no te conoce, que está scrolleando sin pensar, que decide en 2 segundos si te ve o te salta. Su propósito es producir suficiente interacción y retención como para que el algoritmo te empuje a audiencias nuevas. Cada post de Engagement bien hecho es publicidad gratis.

### 12.2 Cuándo usarlo en el embudo

- **Top of funnel pesado:** hábitat natural.
- **Calentamiento de cuentas nuevas:** 35–40% del calendario hasta tener masa crítica.
- **Mantenimiento de visibilidad:** cuentas establecidas también requieren al menos 2 piezas semanales.

Sin Engagement durante 14 días, el alcance orgánico se desploma porque las métricas de interacción rápida bajan.

### 12.3 Las 6 sub-categorías de Engagement

1. **Memes y humor de nicho** — chistes específicos de los dolores de tu industria.
2. **Datos y curiosidades impactantes** — estadísticas, hallazgos, comparativas que frenan el scroll.
3. **Tendencias virales** — montarte en audios o formatos que ya están escalando.
4. **Antes/después y contenido satisfying** — transformaciones visuales, time-lapses.
5. **Listas, rankings y "tipos de"** — formatos digeribles tipo "5 errores de…".
6. **Encuestas binarias y "this or that"** — interacción de un toque, baja fricción.

### 12.4 Tendencias virales — reglas operativas (sub-categoría 3 ampliada)

**Detección:** revisa pestaña Trending de Reels (flecha verde de "Trending"), TikTok Creative Center (Trending Sounds + Hashtags), herramientas como Meedro, Zetrr, ViralFindr, Tokboard. Trends24.in para hashtags trending en X.

**Ventana de oportunidad:** 5 a 10 días útiles. Después, montarte se ve tarde.

**Adaptación, no imitación:** cambiar el contexto pero respetar el formato/audio. Copia literal pierde; cambio total no se reconoce.

**Filtro de marca:** ¿esto refuerza mi posicionamiento o solo me da likes baratos?

**Tendencias a evitar siempre:** tragedias, política partidista, religión, drama de celebridades no relacionado, audios sexualizados que no calzan con tu nicho.

**Velocidad de ejecución:** publicar dentro de 24–48 horas de detectar.

**Importante: la skill no inventa tendencias.** Cuando se solicita contenido de tendencia, la skill pide al usuario que indique qué audio/formato está viral en su nicho ahora. Si no lo tiene, recomienda las herramientas listadas.

### 12.5 Qué compartir (matriz)

| Sub-categoría | Incluir | Evitar |
|---|---|---|
| Memes | Dolor o situación específica del cliente ideal; remate inesperado | Memes genéricos sin nicho |
| Datos | Cifra concreta + contexto + fuente verificable; visual fuerte | Datos sin fuente; estadísticas vagas |
| Tendencias | Audio/formato actual; adaptación al nicho; ejecución rápida | Tendencias muertas; copia literal |
| Antes/después | Transformación visual real; tiempo o esfuerzo claro | Truculencias; transformaciones falsas |
| Listas | Número específico (3, 5, 7); ritmo; punta de remate | Listas de 15+; sin ritmo |
| Encuestas binarias | Dilema que cualquiera contesta en 1 segundo; contraste claro | Opciones complejas; ambigüedad |

### 12.6 Anatomía de un post de Engagement

**Movimiento 1 — Gancho explosivo (0–1 segundo):** imagen, frase, sonido o contraste visual que frene el dedo. NO intro, NO saludo. Choque inmediato.

**Movimiento 2 — Promesa o contraste (1–3 segundos):** qué viene. Por qué seguir mirando.

**Movimiento 3 — Desarrollo rápido (3–15 segundos):** el contenido principal. Ritmo alto. Cortes cada 1–3 segundos en Reels. En carrusel, una idea por slide, máximo 15 palabras.

**Movimiento 4 — CTA suave de interacción:** "Comenta cuál eres tú", "Etiqueta a quien te recordó", "¿Te pasa? Vota arriba".

**Regla de duración:** Reel ≤ 30 segundos. Carrusel ≤ 7 slides.

### 12.7 Biblioteca de ganchos (20 plantillas)

1. "El [%] de los [grupo] hace esto y no lo sabe"
2. "Cosas que solo entiende quien [actividad específica de tu nicho]"
3. "Si te pasa esto, somos los mismos"
4. "POV: [situación dolorosa relatable de tu cliente]"
5. "El error que el 90% de [tu audiencia] está cometiendo ahora mismo"
6. "Esto no debería sorprenderte, pero…"
7. "Antes de [actividad] vs. después de [actividad]"
8. "Tipos de [X] que existen"
9. "Cosas que [tu cliente] dice que sí, pero por dentro está pensando…"
10. "Lo que NADIE te dice de [tu nicho]"
11. "Mito: [creencia común]. Realidad: [verdad]"
12. "Si tu [referente] hace [X], huye"
13. "[Estadística específica] y aquí está por qué"
14. "5 cosas que aprendí después de [logro o fracaso]"
15. "Cuando [situación común de tu nicho]"
16. "Etiqueta a alguien que [comportamiento típico]"
17. "Esto es lo que pasa cuando [situación específica]"
18. "POV: eres [perfil de tu cliente] y…"
19. "Cosas que pensaba antes de [transformación] vs. lo que pienso ahora"
20. "El día que [evento absurdo de tu industria] me cambió"

### 12.8 Plantilla de caption

```
[GANCHO en una línea — pregunta, dato, frase choque]

[CONTEXTO breve — 1-2 líneas que amplían el gancho]

[REMATE u opinión corta — la idea que cierra el ciclo]

[CTA SUAVE — comentario, etiqueta, voto, "te pasa?"]
```

Reglas: caption ≤ 100 palabras.

### 12.9 CTA filtrante (técnica avanzada para tendencias virales)

En posts de tendencia viral o de alto alcance, usar **CTA filtrante** en lugar de "síguenos para más":

❌ Genérico: *"Síguenos para más contenido"* (penalizado por algoritmo)
✅ Filtrante: *"Sígueme si eres [perfil específico] y quieres [resultado específico]"*

Ejemplos:
- Belleza: *"Sígueme si tienes más de 35 y quieres que tu piel envejezca al ritmo que TÚ decides."*
- Marketing con IA: *"Sígueme si vendes algo en internet y estás cansado de cursos genéricos."*
- Marketing digital: *"Sígueme si manejas agencia y quieres dejar de pelear con clientes baratos."*
- Seducción: *"Sígueme si llevas años trabajando 'tu juego' sin trabajar tu vida."*

El filtrante convierte 3–6% de no-seguidores; el genérico, 0.5–1%.

### 12.10 Ejemplos completos

**Ejemplo 1 — Belleza (Datos + Antes/después, Reel 20s):**

Texto pantalla seg 0–2: *"El 80% de las arrugas que ves en el espejo NO son por edad."*
Seg 2–5: split-screen con dos pieles distintas
Seg 5–12: Camila a cámara: *"Son por daño solar acumulado. La diferencia entre estas dos pieles no es la edad. Es 30 años de protección solar."*
Seg 12–18: dispenser de protector. *"Si solo vas a hacer una cosa por tu piel en tu vida, que sea esta."*
Seg 18–20: *"¿Cuántos días a la semana te pones protector? Comenta el número."*

**Ejemplo 2 — Marketing con IA (Listas, Carrusel 6 slides):**

Slide 1: *"5 tipos de personas usando ChatGPT. Confiesa cuál eres."*
Slide 2: **El Copia-Pega** — *Le pide a ChatGPT un email, lo copia tal cual, lo manda. Su cliente le dice "este texto está raro."*
Slide 3: **El Steve Jobs Wannabe** — *Empieza todos sus prompts con "Escribe como Steve Jobs". Termina con copy de vendedor de Iron Man.*
Slide 4: **El Sin Contexto** — *Pide "una estrategia de marketing" y se queja de que no sirve. No le dijo el producto ni el público.*
Slide 5: **El Eterno Free** — *18 meses con la versión gratis. Se queja en X que "ChatGPT está peor cada vez". No probó pago.*
Slide 6: **El que ya entendió** — *Construyó un sistema de prompts. Le ahorra 20 horas/semana. No habla del tema porque está facturando.*

**Ejemplo 3 — Marketing digital (Tendencia viral, Reel 15s):**

Adaptación de audio "Of course, of course":
- Cliente: *"Quiero un anuncio que se haga viral."* / Laura: *"Of course, of course."*
- Cliente: *"Y que cueste poco."* / Laura: *"Of course."*
- Cliente: *"Y para mañana."* / Laura: *"Of course."*
- Cliente: *"Y sin tener que aparecer yo en cámara."* / Laura: *(silencio)* *"…ok eso no."*
Texto pantalla: *"Cuando el cliente cree que el marketing es magia."*

**Ejemplo 4 — Coaching seducción (Memes/POV, Reel 25s):**

Texto pantalla: *"POV: ves a una mujer que te gusta y empiezas a planear la conversación en tu cabeza."*
Voz en off con pensamientos: *"Si me ve voltear, ya cagué" / "¿Y si finjo que estaba viendo el menú?" / "¿Y si la saludo con la mano? No, raro" / "¿Y si me caso con ella? Sí, casarse primero. Más fácil que saludar"*
Cierre: *"Lo único que tenías que hacer era decir hola."*

**Ejemplo 5 — Marketing digital (Encuesta binaria, Carrusel 5 slides):**

Slide 1: *"Dilemas reales de cualquier agencia. Vota slide por slide."*
Slide 2: *Cliente que paga puntual pero pide cambios infinitos vs. Cliente que se demora pagando pero respeta tu criterio*
Slide 3: *Pelear por proyecto que paga 3 meses de gastos vs. Decir que no y aguantar 6 meses*
Slide 4: *Reunión de 1 hora para alinear vs. Reunión de 15 min y todo por escrito*
Slide 5: *Si elegiste todas primeras: estás escalando con dolor. Todas segundas: con criterio. Mezcla: aprendiendo. Es lo más sano.*

**Ejemplo 6 — Coaching seducción (Antes/después puro, Reel 30s):**

Foto del coach hace 4 años. Texto: *"2021. Cuatro relaciones rotas, 0 ganas de seguir intentando."*
Cuts rápidos: cocinando con amigos, gym, leyendo, conociendo gente nueva. Voz en off: *"Lo que cambió no fueron las técnicas. Fueron las amistades, los hobbies, los músculos, los libros."*
Foto actual: *"Hoy. 4 años con la misma mujer. Sin haber aprendido una sola técnica."*
Cierre a cámara: *"Construí la vida primero. La pareja vino después."*
CTA filtrante: *"Sígueme si eres hombre y ya entendiste que la vida amorosa es síntoma, no causa."*

### 12.11 KPIs y métricas

**Métricas duras:**
- Alcance bruto: 5–10x número de seguidores en posts exitosos
- Tasa de interacción ≥ 6% para Reels, ≥ 4% para carrusel
- Saves y shares > likes y comentarios (señales más fuertes)
- Retención de Reels ≥ 60% completed
- Crecimiento de seguidores en 7 días post-publicación
- Velocidad de primeras interacciones (primera hora)

**Métricas blandas:**
- Etiquetados a otros usuarios
- Reposts a stories de no seguidores
- Aparición en "Explorar"

### 12.12 Errores comunes

1. Memes genéricos sin nicho
2. Datos sin fuente
3. Tendencias forzadas
4. CTA invasivo ("síguenos para más")
5. Engagement bait obvio
6. Repetir el mismo formato 5 veces seguidas
7. Confundir Engagement con Conversión
8. Tendencias en zonas tóxicas (política, tragedias)
9. Visual aburrido
10. Listas demasiado largas (>7 puntos)

### 12.13 Cadencia recomendada

- 2–4 posts/semana, 25–30% del calendario en cuentas en crecimiento
- Horarios: 12:00–14:00 y 18:00–21:00
- Distribución sugerida 4 semanas: rotar entre las 6 sub-categorías
- Formato dominante: Reel > carrusel > foto/encuesta

---
