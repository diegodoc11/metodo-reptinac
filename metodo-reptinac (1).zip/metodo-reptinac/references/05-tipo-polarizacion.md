# Tipo 3 — POLARIZACIÓN

*Diferenciación confrontacional. Modos episódico vs sostenido, 8 reglas de seguridad no negociables, 4 ejemplos completos.*

---

## 13. POLARIZACIÓN

### 13.1 Propósito

Polarización **toma postura contra algo establecido** — práctica de tu industria, creencia común del cliente, mito repetido como verdad, tendencia cultural. Su objetivo no es generar engagement (eso entretiene); es **forzar a la audiencia a tomar partido**. Al hacerlo, filtra a quienes no encajan y refuerza la lealtad de quienes sí.

En mercados saturados, donde la diferenciación técnica desapareció, Polarización es la forma más eficiente de decir algo distinto: no afirmando una verdad nueva, sino confrontando una vieja.

**Lo que Polarización NO es:**
- No es drama gratuito. Drama ataca por atacar; Polarización ataca con argumento.
- No es contenido de odio. Atacas prácticas, mitos, creencias — nunca personas o grupos vulnerables.
- No es opinión personal disfrazada. Necesitas los recibos: experiencia, datos o observación específica.

### 13.2 Cuándo usarlo en el embudo

- **Top of funnel para cuentas con autoridad ya construida:** en cuenta nueva (<1.000 seguidores) suele ser contraproducente.
- **Middle of funnel para diferenciación:** ideal para que un lead que está comparándote con la competencia te elija.
- **NO usar en Conversión directa:** Polarización siembra; otros tipos cosechan.

### 13.3 Modos de cadencia

**Modo episódico (postura distinta cada vez):** 1–2 al mes máximo.

**Modo temático sostenido (martilleo a UNA práctica específica):** hasta 1 por semana, con condiciones estrictas. Ejemplo: un coach atacando "VSL Funnel High Ticket" durante 6 meses con ángulos distintos — *"está saturado", "Andrómeda Update lo mató", "el cuello de botella es el creativo, no el closer", "20 creativos virales rinden 10x"*.

**Condiciones para habilitar modo sostenido:**
1. Argumento robusto y evidencia abundante (>20 ángulos sin agotarse)
2. Tema estratégicamente central
3. Tu producto/servicio ES la alternativa
4. Cada pieza ataca un ángulo distinto del mismo problema
5. Compromiso de 6+ meses

| Modo | Frecuencia | Cuándo elegir |
|---|---|---|
| Episódico | 1–2/mes | Marca general, sin foco anti-algo específico |
| Temático sostenido | Hasta 1/semana | Posicionamiento contra práctica establecida central a tu oferta |
| Híbrido | 1 sostenido/semana + 1 episódico/mes | Avanzado, requiere oficio |

### 13.4 Las 5 sub-categorías

1. **Contra prácticas establecidas en tu industria** — atacas cómo se hace algo, no a quien lo hace. La más segura.
2. **Contra mitos o creencias del cliente** — confrontas a tu propia audiencia con cariño y argumento.
3. **Contra figuras o gurús específicos** — la más arriesgada. Solo con argumento sólido. Critica el mensaje, no la persona.
4. **Contra-tendencia cultural o de mercado** — cuando todos van a un lado, tú dices lo contrario, con datos.
5. **Auto-confrontación gremial** — criticar tu propia industria mientras formas parte. La más diferenciadora.

### 13.5 Reglas de seguridad (no negociables)

1. **Atacar prácticas, no personas.** "Las clínicas que prometen X" no "La doctora Y".
2. **Tener los recibos.** Solo polarizar con evidencia, experiencia o argumentos sólidos.
3. **No polarizar desde resentimiento.** Si nace de envidia o pelea no resuelta, no se publica.
4. **Anticipar la objeción más fuerte.** Si tu argumento se rompe con la primera objeción obvia, no estás listo.
5. **Ofrecer alternativa.** Polarización pura crítica es destructiva. Útil dice "esto está mal Y esto sí funciona".
6. **No polarizar sobre temas no relacionados con tu nicho.** Política partidista, religión, identidad de género, conflictos geopolíticos — no son tu campo.
7. **No polarizar contra grupos vulnerables.** Nunca. La skill se niega a producir esto independiente de cómo se solicite.
8. **Aceptar el rebote.** Modera con criterio. No huyas del post.

### 13.6 Diferencia operativa con "Valores y creencias" (Relacionamiento)

| Variable | Valores (Relacionamiento) | Polarización |
|---|---|---|
| Tono | "Yo creo en…" | "Esto está mal y nadie lo dice" |
| Foco | Afirmativo, hacia adentro | Confrontacional, hacia afuera |
| Resultado deseado | Comentarios de afinidad | Comentarios divididos (a favor y en contra) |
| KPI principal | Comentarios cualitativos | Compartidos por desacuerdo + crecimiento filtrado |
| Riesgo | Bajo | Alto si se ejecuta mal |

**Pregunta de prueba:** *¿Estoy compartiendo en qué creo, o estoy diciendo que lo que cree alguien más está mal?* La primera es Relacionamiento; la segunda es Polarización.

### 13.7 Anatomía

**Movimiento 1 — Postura clara, sin rodeos (0–3 segundos):** la postura aparece de entrada. NO introducción.
- ❌ "Hoy les voy a hablar de algo que me preocupa…"
- ✅ "El 80% de los marketeros que se llaman expertos en IA no han manejado un presupuesto real en 2 años."

**Movimiento 2 — El argumento principal:** por qué piensas eso. Datos, experiencia, observación.

**Movimiento 3 — Anticipación del contraargumento:** *"Me vas a decir X. Y tienes razón en parte. Pero…"*

**Movimiento 4 — La alternativa o reframe:** lo que SÍ debería hacerse.

**Movimiento 5 — Filtro de audiencia (CTA específico):** *"Si esto te resonó, estamos en la misma página. Si te molestó, probablemente no soy tu cuenta."*

### 13.8 Biblioteca de ganchos (20 plantillas)

1. "Lo voy a decir aunque me cueste seguidores: …"
2. "Tengo una opinión impopular sobre [tema] y la voy a sostener."
3. "El [%] de [profesionales de mi nicho] hace esto mal. Yo entre ellos hace [X tiempo]."
4. "Esto te va a molestar si eres [perfil específico] y te lo voy a decir igual."
5. "[Práctica común] no funciona. Y todos lo sabemos pero seguimos haciéndolo."
6. "Hay algo que el gremio no se atreve a decir y yo sí."
7. "Llevamos años repitiendo [mito] como verdad. No lo es."
8. "Lo más impopular que voy a publicar este año:"
9. "[Práctica establecida] le hace más daño a [tu cliente] que el problema que dice resolver."
10. "Soy parte del gremio que voy a criticar. Por eso lo puedo decir."
11. "Mientras todos te dicen [X], yo te digo lo opuesto."
12. "Este post va a perder seguidores. Está bien."
13. "Te están vendiendo [X] como solución. No lo es."
14. "Hay un consenso en mi industria con el que no estoy de acuerdo."
15. "Si te enseñaron [X], te enseñaron mal."
16. "Vengo a tirar piedras. Las tengo."
17. "Esto lo piensan muchos profesionales y pocos lo publican."
18. "Disculpas anticipadas a quien se sienta aludido."
19. "[Tu cliente] cree que su problema es X. No lo es. Es Y."
20. "Voy a confrontar a mi propio gremio. Empiezo por mí."

### 13.9 Plantilla de caption

```
[POSTURA en una línea — directa, sin rodeos]

[CONTEXTO breve — por qué hablas de esto ahora]

[ARGUMENTO con evidencia o experiencia personal]

[ANTICIPACIÓN del contraargumento + tu respuesta]

[ALTERNATIVA o reframe — qué hacer en su lugar]

[FILTRO de audiencia — CTA que separa los tuyos de los demás]
```

Reglas: 150–300 palabras. Polarización requiere espacio para sostener argumento.

### 13.10 Ejemplos completos

**Ejemplo 1 — Belleza (Auto-confrontación gremial, Reel 60s):**

Gancho: *"El 60% de las pacientes menores de 30 que entran a una clínica estética no necesitan procedimiento. Necesitan rutina. Y las clínicas — la mía incluida hasta hace 2 años — se lo callan."*

> Soy doctora estética. Vivo de procedimientos. Y voy a decir algo que me va a costar pacientes.
>
> Cuando una mujer de 24 años entra a tu consulta porque "se ve cansada", la respuesta correcta no es venderle bótox preventivo, ni un facial de $400, ni un paquete de 6 sesiones de algo. La respuesta correcta es preguntarle cuánto duerme, qué come, y si usa protector solar todos los días.
>
> Tú me vas a decir: "Camila, así no facturas". Tienes razón. Por eso el modelo está como está.
>
> Yo cambié esa conversación en mi clínica hace dos años. Pierdo entre 4 y 6 ventas al mes que antes cerraba en automático. Pero las pacientes que se quedan vuelven 5 años después, traen a sus amigas, traen a sus hijas. Mi facturación bajó 8% el primer año y subió 30% al segundo.
>
> El cortoplacismo de la industria se come la confianza de las pacientes. Y la confianza es el único activo que no escala con marketing.
>
> Si eres paciente: pregunta a tu doctora si lo que te está vendiendo lo necesitas o solo lo puedes pagar. Si eres colega: ya sabes a qué me refiero.

CTA filtro: *"Sígueme si eres paciente que prefiere honestidad antes que descuento, o profesional cansado del modelo de venta agresiva."*

**Ejemplo 2 — Marketing con IA (Contra mitos del cliente, Carrusel 8 slides):**

Slide 1: *"La IA no te va a 10x el negocio. Tu negocio sigue siendo malo."*
Slide 2: *Llevo dos años escuchando a clientes pedirme que "les meta IA" para crecer. Como si la IA fuera fertilizante.*
Slide 3: *La verdad: la IA es un amplificador. Si tu propuesta de valor es débil, la IA te ayuda a escalar el fracaso más rápido.*
Slide 4: *Vi a una marca con producto regular invertir 8 mil dólares en automatización con IA y duplicar sus ventas en 3 meses. También vi sus reembolsos duplicarse. El fundador renunció al año.*
Slide 5: *Tú me vas a decir: "Hay casos donde la IA salvó negocios". Sí. Negocios que ya tenían producto bueno. La IA aceleró lo que ya funcionaba.*
Slide 6: *La IA NO arregla: producto mediocre, propuesta confusa, mercado equivocado, equipo desalineado, modelo inviable.*
Slide 7: *Antes de "meterle IA", contesta: ¿la gente ya quiere lo que vendes? ¿Repite? ¿Recomienda? Si tres síes, la IA te va a multiplicar. Si un no, te va a desnudar.*
Slide 8: *Si vendes mal, automatizar es escalar el problema. Si vendes bien, automatizar es despegar. Decide en cuál estás.*

**Ejemplo 3 — Marketing digital (Contra prácticas establecidas, Reel 50s):**

Gancho: *"Llevo 4 años cobrando las llamadas de descubrimiento. Y voy a decir por qué las agencias que no cobran están regalando su trabajo más caro."*

> En mi industria, la "llamada de descubrimiento" gratuita es ley. 60 minutos en los que el cliente te cuenta sus problemas y tú le devuelves un mini-diagnóstico para que decida contratarte.
>
> Eso no es llamada de descubrimiento. Es consultoría estratégica gratis. La mayoría de agencias regala 5 o 6 al mes — un día de trabajo no facturado, todos los meses.
>
> Tú me vas a decir: "Pero así se cierra la venta". Y te digo que no. Así se cierra con el cliente que iba a comprar igual. Para el resto, regalaste tu inteligencia y se llevaron el diagnóstico a la competencia más barata.
>
> En mi agencia cobramos $150 USD la llamada. Acreditables al primer mes si firman. ¿Cuántos clientes pierdo por eso? 3 de cada 10. ¿Y los otros 7? Llegan calificados, respetan el tiempo del equipo, y cierran al 65%, no al 20%.
>
> El cliente que no quiere pagar tu diagnóstico tampoco va a respetar tu estrategia.

**Ejemplo 4 — Coaching seducción (Contra-tendencia cultural, Reel 70s):**

Gancho: *"Si tu coach de seducción te enseña a manipular, no te está enseñando seducción. Te está enseñando ansiedad disfrazada de confianza."*

> Llevo 6 años en este nicho. Y llevo 6 años viendo cómo la mitad de mis colegas le venden a hombres rotos un manual para volverlos más rotos.
>
> "Técnicas para que te diga sí". "Frases que rompen la barrera". "Cómo manipularla sin que se dé cuenta". Búscalo. Está vivo. Está vendiéndose ahora mismo.
>
> Esto pasa con un hombre que aprende manipulación: en el primer encuentro le funciona. Es novedad. La técnica sorprende. En la cita 3, ella nota algo raro. En la cita 5, ella se va y él no entiende. La conclusión del hombre: "necesito mejor técnica". Y compra el siguiente curso del siguiente coach manipulador. Ciclo cerrado.
>
> Me vas a decir: "Pero las técnicas funcionan al principio". Sí. También funcionan los esteroides al principio. La pregunta no es si funciona el lunes. Es si funciona en 5 años, con la misma persona.
>
> La seducción real no es manipular. Es volverte alguien con quien valga la pena pasar la vida. Y eso no se aprende con frases. Se aprende construyendo una vida, una identidad, una presencia que la otra persona quiera elegir, no que tenga que descifrar.
>
> Si vienes buscando trucos, no soy tu coach. Si vienes buscando volverte alguien que no necesita trucos, hablamos.

### 13.11 KPIs y métricas

**Métricas duras:**
- Comentarios divididos: 60–70% a favor, 30–40% en contra (señal de buena polarización)
- Compartidos: 1 cada 200 alcance
- Crecimiento simultáneo de follow + unfollow (filtra)
- Saves ≥ 1.5x el promedio del perfil

**Métricas blandas:**
- Citas en contenido de otros creadores
- Aparición de tu nombre en debates del nicho

### 13.12 Errores comunes

1. Atacar personas en lugar de prácticas
2. Polarizar sin recibos
3. Repetir la misma polarización (en modo episódico)
4. Confrontar para temas no relacionados
5. Polarizar desde resentimiento
6. No anticipar la objeción
7. No ofrecer alternativa
8. Lenguaje despectivo o discriminatorio
9. Publicar y huir
10. Polarizar con demasiada frecuencia (en modo episódico)
11. Polarizar en zonas tóxicas
12. Confundir Polarización con drama gratuito

### 13.13 Cadencia recomendada

- Modo episódico: 1–2/mes
- Modo sostenido: hasta 1/semana con condiciones estrictas
- Hora ideal: 18:00–21:00 (audiencia con tiempo para discutir)
- Formato dominante: Reel a cámara > carrusel argumentativo > post de texto largo

---
