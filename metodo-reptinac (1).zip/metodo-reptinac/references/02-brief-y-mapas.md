# Inputs Críticos: Brief, Banco de Auto-Aplicación, Mapa de Dolores

*Brief de marca completo (15 secciones), Banco de Auto-Aplicación, Mapa de Dolores en 4 niveles, Test de Amenaza Concreta.*

---

# PARTE II — INPUTS CRÍTICOS DEL USUARIO

Sin los inputs de esta parte, el método produce contenido genérico. El Brief de Marca, el Banco de Auto-Aplicación y el Mapa de Dolores son **estructurales**, no opcionales.

## 6. Brief de Marca / Story Bank

El Brief de Marca es el documento maestro que alimenta todos los tipos de contenido. Se llena una vez, se actualiza cada 6 meses, y queda guardado como referencia permanente.

### 6.1 Modos de configuración

El Brief admite dos modos:

**Modo libre (recomendado para creadores que se sienten más cómodos contando que llenando):**
> *"Cuéntame tu historia como si me la estuvieras contando a un amigo en un café — desde antes de meterte en esto, los momentos clave, los fracasos, las veces que tu propio producto te salvó. Habla todo lo que quieras, sin orden."*

Después del relato libre, la skill identifica qué secciones del brief quedaron cubiertas y dispara 3–5 preguntas puntuales para llenar los huecos críticos — especialmente Banco de Auto-Aplicación y Mapa de Dolores.

**Modo estructurado:**
La skill hace preguntas sección por sección siguiendo el guion de las 15 secciones (abajo).

### 6.2 Las 15 secciones del Brief de Marca

**A. Identidad core**
- Nombre, edad, ubicación
- Profesión y nicho específico
- Qué vendes exactamente (productos/servicios + rango de precios)

**B. Tipo de negocio y nicho**
- Categoría: marca personal high-ticket / negocio local de servicio / e-commerce / B2B / creador de contenido / infoproducto
- Nivel de competencia del nicho (alto / medio / bajo)
- Etapa de cuenta: nueva (<10K seguidores) / en crecimiento / establecida (50K+) / en lanzamiento activo

**C. Cliente ideal específico** (perfil demográfico, contexto, momento de vida)

**D. Viaje del héroe (estructura clásica adaptada)**
1. Vida ordinaria antes del nicho
2. Llamado a la aventura (cómo descubriste la oportunidad)
3. Resistencia o dudas iniciales
4. Catalizador (quién o qué te empujó)
5. Cruce del umbral (fecha y momento del primer paso)
6. Pruebas y fracasos (3 errores grandes del camino)
7. Crisis profunda (el momento más oscuro)
8. Transformación interna
9. Retorno con el elixir (lo que ahora vendes a otros)

**E. Banco de momentos pivote** (3+ con fecha, lugar, frase exacta, qué cambió después)

**F. Banco de fracasos con aprendizaje** (3+)

**G. Banco de victorias inesperadas o emotivas** (3+ — no las grandes, las pequeñas que te emocionaron)

**H. Banco de Auto-Aplicación** (8+) — ver sección 7 en detalle

**I. Posturas y valores**
- 3 cosas que defiendes en tu industria
- 3 cosas con las que NO estás de acuerdo
- 3 frases que repites en privado

**J. Tribu**
- Mentores reales (nombre + qué te aportó cada uno)
- Equipo / socios
- Clientes con permiso para mencionar
- Comunidad o grupo de pertenencia

**K. BTS / vida cotidiana**
- Rutina de trabajo
- Herramientas que usas
- Dónde trabajas físicamente
- Rituales pre y post trabajo
- Lecturas, podcasts, referentes actuales

**L. Vulnerabilidades presentes**
- 3 cosas que aún te cuestan en tu trabajo HOY
- 1 miedo profesional actual
- 1 área donde sigues siendo principiante

**M. Conexión profunda con la oferta**
- ¿Qué problema TUYO resolviste, que ahora ayudas a otros a resolver?
- ¿Cómo lo que vendes hoy fue, primero, una solución para ti?

**N. Mapa de creencias del nicho** (combustible para Polarización)
- 5+ mitos populares en tu nicho
- 5+ verdades incómodas que el gremio no dice
- 3+ prácticas saturadas o contraproducentes
- 3+ enfoques de figuras conocidas con los que NO estás de acuerdo
- Tesis central para Polarización sostenida (si aplica)

**O. Mapa de Dolores del Avatar** (en 4 niveles) — ver sección 8 en detalle

## 7. Banco de Auto-Aplicación (sección H del Brief, ampliada)

Esta es la mina más rica del método. Cada vez que lo que vendes te ha ayudado a ti en una situación específica de tu vida, generas una semilla de contenido que combina 4 tipos a la vez (Relacionamiento + Autoridad + Niveles de Consciencia + Conversión) sin sentirse vendedor.

### Estructura del Banco de Auto-Aplicación

Lista mínimo 8 momentos en los últimos 24 meses donde lo que vendes te ayudó a ti mismo. Para cada momento responde:

1. ¿Cuándo y dónde fue? (fecha, lugar, contexto)
2. ¿Qué situación enfrentabas? (la tensión real)
3. ¿Qué herramienta/técnica/principio de los que enseñas aplicaste?
4. ¿Cómo te fue? (resultado con detalles)
5. ¿Qué le diría esto a un cliente que duda?

### Cómo lo usa el método

8 momentos × 4 ángulos (Relacionamiento, Autoridad, Niveles de Consciencia, Conversión) = 32 piezas únicas de altísima calidad. Cuando se solicita generar una pieza de cualquiera de los tipos compatibles, el método consulta este banco y elige UN momento como semilla.

### Ejemplo de momento bien documentado

> **Coach de habilidades sociales:**
> 1. Octubre 2024, charla TEDx en Bogotá
> 2. 800 personas en el auditorio, 4 minutos antes de subir, manos sudadas, pánico real
> 3. La técnica de "exposición gradual a la incomodidad" del módulo 3 — la misma que enseño cuando un alumno se acerca a una mujer en la calle por primera vez
> 4. Bajé el ritmo cardíaco respirando 4-7-8, me forcé a hacer contacto visual con 3 personas del público antes de empezar, y a los 30 segundos ya estaba en flow
> 5. *"Si esto me funciona en un escenario donde TODO el mundo me está mirando, te funciona a ti acercándote a una desconocida en un café."*

## 8. Mapa de Dolores del Avatar (sección O del Brief, ampliada)

Sin un mapa preciso de los dolores del avatar, los tipos Niveles de Consciencia, Polarización y Conversión producen contenido genérico que no logra que el lector se sienta visto — y si el lector no se siente visto, no compra.

### Los 4 niveles del Mapa de Dolores

**Nivel 1 — Dolor Externo (práctico, visible)**
El síntoma físico, diario, observable. Lo que la persona ve en el espejo, en sus números, en su realidad concreta. El nivel más superficial.

**Nivel 2 — Dolor Interno (emocional, identitario individual)**
Cómo el dolor externo la hace sentir consigo misma. La conversación interior cuando nadie la está viendo.

**Nivel 3 — Dolor Relacional (vínculos, sociedad cercana)**
Cómo el dolor afecta sus relaciones — pareja, familia, amigos, círculos profesionales. Lo que las otras personas notan, dicen o dejan de decir.

**Nivel 4 — Dolor Filosófico (identitario colectivo, existencial)**
Qué dice esto sobre quién es esta persona en el mundo, sobre la sociedad, sobre el sentido de su vida.

### Modos de configuración

- **Si el usuario tiene la lista de dolores**: la pega y se usa directamente.
- **Si no la tiene**: el método genera una propuesta basada en (1) avatar definido en sección C, (2) producto/servicio, (3) transformación prometida. Devuelve mapa de 4 niveles × 5 dolores cada uno (20 dolores totales). El usuario valida, edita o agrega.

**Sin mapa validado, los tipos Niveles de Consciencia, Polarización y Conversión NO se generan** — porque sin dolores específicos, esos tres producen humo.

## 9. Test de Amenaza Concreta (regla para dolores filosóficos)

Los dolores filosóficos NO deben redactarse como preguntas existenciales abstractas. Deben pasar el **Test de Amenaza Concreta**: ¿qué le va a pasar específicamente a esta persona, en cuánto tiempo, si no resuelve esto?

**Abstracto (débil):** *"¿Qué significa ser útil en una era de IA?"*
**Concreto (fuerte):** *"Si no domino IA en los próximos 12 meses, alguien que sí la domine va a hacer mi trabajo por la mitad de lo que cobro."*

El segundo es filosófico (cuestiona su lugar en el mundo profesional) **pero anclado a una consecuencia material y temporal específica**. Esa ancla es lo que activa el cuerpo del lector.

Regla operativa: cualquier dolor filosófico que no pase este test debe reescribirse antes de usarse como semilla de contenido.

## 10. Cómo va a manejar la skill las correcciones del usuario

Cuando la skill genere un Mapa de Dolores propuesto y el usuario diga *"esto está mal, esto duele más"*, el protocolo es:

1. Aceptar la corrección como autoridad final (el usuario conoce a su avatar mejor que cualquier framework).
2. Aplicar el Test de Amenaza Concreta a los dolores reescritos.
3. Re-procesar el mapa completo, no solo el dolor corregido — porque la corrección suele revelar que otros dolores del mismo nivel también están mal.
4. Devolver el mapa actualizado para validación final.

---
