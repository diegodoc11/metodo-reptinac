# Anexo C — Mapa de Dolores: Ejemplos Completos en 4 Nichos

*Mapa completo en 4 niveles para: belleza/medicina estética, marketing con IA, marketing digital, coaching habilidades sociales. 20+ dolores por nicho con Test de Amenaza Concreta aplicado.*

---

## ANEXO C — Mapa de Dolores: ejemplos completos en 4 nichos

### Nicho 1 — Belleza / Medicina estética (avatar: mujer 35–45, profesional, nivel medio-alto)

**Nivel 1 — Externo:**
1. Manchas en la cara que cubre con maquillaje de más cobertura cada año
2. Líneas de expresión que se ven incluso al despertar
3. Caída de papada y pérdida de definición mandibular
4. Ojeras que el corrector ya no disimula
5. Piel que se ve apagada en fotos sin filtro

**Nivel 2 — Interno:**
1. Sensación de que ya no se reconoce en el espejo
2. Vergüenza al verse en fotos sin maquillaje
3. Resignación: *"esto es la edad, ya nada va a cambiar"*
4. Frustración por gastar y no ver cambio
5. Miedo a verse en una foto en redes sociales sin saberlo

**Nivel 3 — Relacional:**
1. Pareja que dejó de hacerle comentarios espontáneos
2. Hijos adolescentes que le piden que no salga con ellos sin maquillarse
3. Compañeras de trabajo más jóvenes que comentan su propia "rutina antiedad"
4. Madre comparándola con ella misma a la misma edad
5. Sentirse invisible cuando entra a un lugar donde antes destacaba

**Nivel 4 — Filosófico (con Test de Amenaza Concreta):**
1. *"Si no detengo este proceso ahora, en 10 años no voy a tener cómo arreglarlo"*
2. *"En mi industria, las mujeres que no cuidan su imagen pierden oportunidades concretas"*
3. *"Si mi pareja deja de mirarme como antes, voy a llegar a los 50 sintiendo que ya nadie me elige"*
4. *"Mis hijas me están viendo envejecer mal — esa es la imagen de envejecer que les estoy enseñando"*
5. *"Llegar a los 60 sintiendo que ya no soy yo es una de mis pesadillas reales"*

### Nicho 2 — Marketing con IA (avatar: emprendedor digital o profesional 28–45)

**Nivel 1 — Externo:**
1. Pasa horas escribiendo prompts y los resultados no son utilizables
2. Tiene 5–10 suscripciones a herramientas IA y no usa ninguna a fondo
3. Sus campañas de pauta no convierten desde hace 6 meses
4. Su productividad sigue igual a pesar de "haberse metido con IA"
5. Sus contenidos se ven igual que los de la competencia

**Nivel 2 — Interno:**
1. Sensación de estar perdiendo el tren mientras otros avanzan
2. Vergüenza de admitir que no sabe usar bien las herramientas
3. Ansiedad cada vez que alguien menciona una herramienta nueva
4. Frustración por gastar dinero en cursos y no ver retorno
5. Imposibilidad de relajarse porque siente que cualquier semana sin estudiar lo deja atrás

**Nivel 3 — Relacional:**
1. Esposa o pareja que cuestiona en cuánto se gasta en herramientas y cursos
2. Equipo o socios que esperan resultados que no llegan
3. Clientes que empiezan a preguntar si "usa IA" y la respuesta corta lo expone
4. Colegas más jóvenes que aplican IA con naturalidad y lo dejan sintiéndose viejo
5. Hijos que ven a papá diciendo que estudia IA y nunca produce nada visible

**Nivel 4 — Filosófico (con Test de Amenaza Concreta):**
1. *"Si no domino IA en los próximos 12 meses, alguien que sí la domine va a hacer mi trabajo por la mitad de lo que cobro"*
2. *"Mi profesión, tal como la conozco, va a ser obsoleta en 3–5 años — y todavía no sé cómo posicionarme"*
3. *"Si pierdo este momento, voy a quedarme repitiendo lo que aprendí hace 10 años hasta que nadie me contrate"*
4. *"Mis hijos van a crecer en un mundo donde papá no entendió la transición y se quedó atrás"*
5. *"Llevo 18 meses 'estudiando IA' sin un solo proyecto que muestre — eso me dice algo de mi capacidad real"*

### Nicho 3 — Marketing digital (avatar: dueño de agencia o de negocio 30–50)

**Nivel 1 — Externo:**
1. Funnel que pasó de convertir 4% a 1.2% en 6 meses
2. CPL en Meta Ads se duplicó desde el año pasado
3. ROAS bajó del 3.5x al 1.8x sin saber por qué
4. Cuesta cerrar al cliente premium — todos negocian a la baja
5. Equipo gastando 40% del tiempo en reuniones internas

**Nivel 2 — Interno:**
1. Sensación de estar haciendo lo mismo que antes y obtener menos
2. Duda profunda sobre si el modelo de agencia/negocio sigue siendo viable
3. Ansiedad al revisar el dashboard cada mañana
4. Vergüenza de admitir que no sabe si su estrategia funciona
5. Cansancio de explicar lo mismo a clientes que no entienden

**Nivel 3 — Relacional:**
1. Socio que cuestiona decisiones cada vez con más frecuencia
2. Mejores empleados pidiendo aumentos que no se pueden pagar
3. Clientes históricos pidiendo descuento o cambiando a la competencia
4. Familia que pide tiempo que no hay
5. Reuniones con CFO o contador que cada vez se sienten más tensas

**Nivel 4 — Filosófico (con Test de Amenaza Concreta):**
1. *"Si no transformo el modelo de mi agencia en 12 meses, voy a estar cerrando como las que ya cerraron"*
2. *"Llevo 8 años construyendo esto — la posibilidad de tener que volver a ser empleado es real"*
3. *"Si mi negocio no escala, voy a llegar a los 50 trabajando más duro por menos plata"*
4. *"Mi equipo confía en mí y si no encuentro la salida, voy a tener que despedirlos"*
5. *"Estoy compitiendo con freelancers de 25 años que cobran un tercio de lo mío y entregan más rápido — la matemática no cierra"*

### Nicho 4 — Coaching habilidades sociales / seducción legítima (avatar: hombre 25–45)

**Nivel 1 — Externo:**
1. Lleva 1+ año sin pareja a pesar de querer una
2. Las pocas citas que tiene terminan después del 2do o 3er encuentro
3. Apps de citas que no producen matches o producen matches que no escalan
4. Cuerpo presente en eventos sociales sin lograr conversación significativa
5. Conoce a alguien que le interesa pero no la vuelve a ver

**Nivel 2 — Interno:**
1. Sensación de "yo no soy ese tipo de hombre" que las mujeres eligen
2. Resignación: *"a esta edad ya es tarde"*
3. Ansiedad al ver a parejas felices en redes sociales o calle
4. Vergüenza de admitir que sigue solo a sus 35
5. Auto-comparación constante con hombres que ve como "el tipo que sí"

**Nivel 3 — Relacional:**
1. Amigos que se casan, tienen hijos, y él sigue saliendo solo
2. Familia preguntando "¿cuándo vas a presentar a alguien?" en cada reunión
3. Compañeros de trabajo asumiendo que es soltero por elección, no por circunstancia
4. Madre que ha dejado de preguntar — lo cual duele más que cuando preguntaba
5. Hermano menor casándose primero

**Nivel 4 — Filosófico (con Test de Amenaza Concreta):**
1. *"Si no encuentro pareja en los próximos 5 años, voy a llegar a los 45 sin haber tenido una relación larga, lo que estadísticamente reduce mucho las posibilidades de tenerla"*
2. *"La ventana para tener hijos biológicos con margen de tiempo se está cerrando — en 10 años va a ser imposible"*
3. *"Si nadie me ha elegido a esta edad, eso me dice algo sobre quién soy que aún no quiero aceptar"*
4. *"Voy a llegar a los 60 sin haber compartido la vida con nadie y la idea me aterra"*
5. *"Mi padre me dijo que el peor regalo que un hombre se puede hacer es llegar viejo solo — ya estoy en camino"*

---
