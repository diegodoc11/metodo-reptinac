# Tipo 4 — TRANSFORMACIÓN

*Enseñar habilidades concretas que demuestran utilidad. CTAs permitidos vs prohibidos, lead magnet por DM como técnica clave.*

---

## 14. TRANSFORMACIÓN

### 14.1 Propósito

Transformación lleva al lector de "no sé cómo hacer X" a "ya lo hice". Es contenido que la audiencia guarda y al que vuelve. Es la prueba más inequívoca de que tu expertise no es teórica.

En el embudo, Transformación es el caballo de batalla del MOFU. Calienta al lead que ya te conoce mostrándole que lo que sabes funciona — sin que tengas que decir "soy experto".

**Lo que Transformación NO es:**
- No es Autoridad. Autoridad demuestra POR QUÉ eres tú quien debe enseñar; Transformación demuestra QUÉ enseñas.
- No es Conversión. Transformación regala valor; Conversión cosecha la venta.
- No es contenido inspiracional disfrazado.

### 14.2 Cuándo usarlo en el embudo

- **MOFU principal:** hábitat natural.
- **TOFU para nichos B2B y técnicos:** la utilidad pura llega antes que la historia.
- **Pre-lanzamiento:** sube a 35–40% del calendario durante 2–3 semanas previas a una venta.

### 14.3 Las 5 sub-categorías

1. **Tutorial paso a paso** — "cómo hacer X en N pasos".
2. **Frameworks y plantillas** — sistemas replicables.
3. **Diagnósticos y auto-evaluaciones** — herramientas para que el lector se ubique.
4. **Errores comunes y correcciones** — "3 errores que cometes y cómo arreglarlos".
5. **Análisis de caso (propio o ajeno)** — descomponer un caso real para extraer lección.

### 14.4 Qué compartir (matriz)

| Sub-categoría | Incluir | Evitar |
|---|---|---|
| Tutorial | Pasos numerados, tiempo estimado, captura del antes/después | Pasos vagos, más de 7 sin sub-agrupación |
| Frameworks | Acrónimo o nombre, ejemplo aplicado, plantilla copiable | Frameworks que son solo listas bonitas |
| Diagnósticos | Preguntas binarias o de pocas opciones, lectura clara | Preguntas ambiguas, diagnóstico que no diferencia perfiles |
| Errores comunes | Error específico + por qué pasa + corrección concreta | "No te rindas" como error; correcciones genéricas |
| Análisis de caso | Hechos verificables, métricas, hipótesis razonables, lección extraíble | Especulación disfrazada; conclusiones sin evidencia |

### 14.5 Anatomía

**Movimiento 1 — Promesa específica (0–3 segundos):** qué va a aprender + en cuánto tiempo. Tangible y medible.
- ❌ "Hoy te enseño cómo mejorar tu marketing"
- ✅ "En 60 segundos te muestro la plantilla de prompt para escribir cualquier anuncio en 2 minutos"

**Movimiento 2 — Setup (problema que resuelve):** una frase. Sin esto, el lector no sabe si necesita el contenido.

**Movimiento 3 — Desarrollo (la sustancia):** los pasos, framework, análisis. 70% del peso. Densidad alta.

**Movimiento 4 — Síntesis memorable:** recap en una frase o gráfico que el lector pueda guardar mentalmente.

**Movimiento 5 — CTA práctico (no de venta):** ver sección 14.7.

### 14.6 Biblioteca de ganchos (20 plantillas)

1. "En [X] minutos te enseño a [resultado específico]"
2. "Si haces esto, [resultado]. En [N] pasos:"
3. "El framework que uso para [resultado], paso a paso:"
4. "Los [N] errores más comunes al [actividad] y cómo arreglarlos"
5. "Te enseño en este post lo que cobré $[X] por enseñarle a un cliente"
6. "Plantilla que puedes copiar y adaptar:"
7. "Cómo [hacer X] sin [obstáculo común]"
8. "Si tu [problema específico] te tiene atascado, esto te lo arregla"
9. "El método [nombre o acrónimo] para [resultado en tiempo]"
10. "[N] pasos para pasar de [estado A] a [estado B]"
11. "La diferencia entre [opción A] y [opción B], explicada en 60 segundos"
12. "Lo que nadie te explicó sobre [proceso]:"
13. "Auto-evaluación: ¿en qué etapa de [proceso] estás?"
14. "Descompongo el lanzamiento de [marca conocida]: 3 cosas que tú puedes copiar"
15. "Si vas a [actividad] esta semana, evita estos 3 errores"
16. "Los [N] pasos que sigue cualquier [proceso] que funciona"
17. "Mira cómo resolví este problema específico:"
18. "Cómo identificar si tu [estrategia/producto] está en problemas"
19. "Hago esto cada [periodo] y cambia mis resultados:"
20. "Si tienes [perfil específico], esto va a servirte directo:"

### 14.7 CTAs PERMITIDOS en Transformación

1. **CTA de utilidad inmediata:** *"Guarda este post para cuando lo necesites."*
2. **CTA de aplicación:** *"Aplica y cuéntame en comentarios cómo te fue."*
3. **CTA de difusión:** *"Etiqueta a [perfil] que necesita esto."*
4. **CTA filtrante de seguidor:** *"Sígueme si quieres dejar de [dolor específico] y llegar a [deseo específico]."*
5. **CTA de lead magnet por DM:** *"Comenta '[palabra clave]' y te envío [plantilla / checklist / PDF / video extendido] por DM."*
6. **CTA de engagement:** *"¿Qué te pareció? ¿Lo aplicarías?"*

**CTAs PROHIBIDOS en Transformación:**
- Cualquier mención de precio, producto pago, link a checkout, nombre de programa de pago.
- *"Para profundizar, mi curso de…"*
- *"Si quieres aprender todo el sistema, mi mentoría está abierta."*

El lead magnet por DM (#5) es probablemente el CTA más rentable de Transformación: convierte un post en operación de construcción de lista sin venta directa.

### 14.8 Plantilla de caption

```
[PROMESA específica con tiempo y resultado — 1 línea]

[SETUP del problema que resuelve — 1-2 líneas]

[DESARROLLO numerado o estructurado — el grueso del valor]

[SÍNTESIS o recap memorable — 1-2 líneas]

[CTA práctico — guarda, aplica, comparte resultado, lead magnet]
```

Reglas: 150–350 palabras según formato.

### 14.9 Ejemplos completos

**Ejemplo 1 — Belleza (Tutorial paso a paso, Carrusel 6 slides):**

Slide 1: *"Si tienes 30+ y no sabes en qué orden aplicar tus productos en la mañana, este post. Rutina de 3 pasos. 5 minutos. Lo demás es ruido."*

Slide 2: **Paso 1 (00:00–01:00) — Limpiador suave**
*Solo agua tibia o limpiador sin sulfatos. Nada que haga espuma agresiva. Si tu piel se siente "tirante" después de lavarla, lo estás haciendo mal.*

Slide 3: **Paso 2 (01:00–03:00) — Sérum con vitamina C (10–15%)**
*4 a 5 gotas. Cara y cuello. Espera 90 segundos a que absorba. Es el ingrediente más subestimado.*

Slide 4: **Paso 3 (03:00–05:00) — Hidratante + protector solar (FPS 50)**
*Hidratante primero, espera 30 segundos, después protector. Generoso. La mayoría se aplica un tercio de la cantidad recomendada.*

Slide 5: **Lo que NO va en la mañana:**
*Retinol (es de noche). Exfoliantes ácidos (de noche o 2 veces a la semana). Aceites pesados (te freirás bajo el sol).*

Slide 6: *3 productos. 5 minutos. Resultados visibles en 8 a 12 semanas. Más complicado que esto, está vendiéndote algo que no necesitas.*

CTA: *"Guarda este post. Y si tienes hija, mamá o hermana que te pregunta — pásalo."*

**Ejemplo 2 — Marketing con IA (Framework + plantilla, Reel 60s + carrusel):**

Reel: *"Te enseño a escribir cualquier anuncio de Meta en 2 minutos con un solo prompt. Plantilla copiable al final."*

Plantilla: *"Actúa como copywriter de respuesta directa con experiencia en Meta Ads. Escribe un anuncio para [PRODUCTO] dirigido a [AUDIENCIA ESPECÍFICA]. Estructura: 1) ATENCIÓN: pregunta o estadística que detenga el scroll. Máximo 8 palabras. 2) INTERÉS: párrafo de 2 frases que conecte con el dolor. 3) DESEO: 3 beneficios concretos en bullets. 4) ACCIÓN: llamado claro con urgencia suave. Tono: directo, sin clichés, sin venta agresiva."*

CTA: *"Comenta qué producto vendes para que adapte la plantilla a ti."*

**Ejemplo 3 — Marketing digital (Diagnóstico, Carrusel 7 slides):**

Slide 1: *"5 preguntas para saber dónde se está rompiendo tu funnel. Responde sí o no. Al final te digo qué arreglar primero."*

Slide 2: **Pregunta 1 — Tráfico:** *¿Estás recibiendo al menos 100 visitas diarias a tu landing?*

Slide 3: **Pregunta 2 — Copy:** *De cada 100 visitas, ¿al menos 30 dan scroll hasta el final?*

Slide 4: **Pregunta 3 — Oferta:** *De cada 100 que dan scroll, ¿al menos 5 dejan datos en el formulario?*

Slide 5: **Pregunta 4 — Follow-up:** *De cada 100 leads, ¿al menos 20 abren tu primer email?*

Slide 6: **Pregunta 5 — Cierre:** *De cada 100 que abren, ¿al menos 3 compran?*

Slide 7: **Donde respondiste NO primero, ahí está el cuello de botella.**
- *NO en 1: tu problema NO es el funnel. Es la pauta o el SEO.*
- *NO en 2: tu copy de landing no engancha.*
- *NO en 3: tu oferta no es lo suficientemente fuerte.*
- *NO en 4: tu segmentación falló o el primer email es genérico.*
- *NO en 5: el problema es la confianza o el precio.*

**Ejemplo 4 — Coaching seducción (Errores comunes, Reel 75s):**

Gancho: *"3 errores que el 80% de los hombres cometen en la primera conversación. Y cómo arreglarlos en 5 segundos cada uno."*

> **Error 1 — Hablar de más cuando estás nervioso.** Cuando el cuerpo siente miedo, el cerebro compensa hablando rápido. Ella te lee como ansioso. La solución: aprende a sostener silencios cortos. 2 segundos de pausa después de algo que dijo ella te hace ver presente, no apurado.
>
> **Error 2 — Preguntas tipo entrevista.** "¿A qué te dedicas? ¿De dónde eres?". Eso es interrogatorio. Cambia "qué" por "cómo" o "por qué". *"¿Cómo terminaste viviendo en esta ciudad?"* abre historia.
>
> **Error 3 — No comentar sobre el contexto.** Estás en un café, hay música, hay gente. El cerebro de presente comenta el momento: *"Esa canción es buena", "Esa pareja del fondo lleva 20 minutos en la misma página del menú."* Comentar el contexto compartido te ancla en la realidad.

CTA: *"Guarda esto y úsalo en tu próxima conversación. Pero úsalo. No lo guardes y olvides como guardaste los 40 posts anteriores que te recomendaron lo mismo."*

### 14.10 KPIs y métricas

**Métricas duras:**
- **Save rate:** indicador #1. Apunta a ≥3% del alcance, ≥5% es excelente.
- Share rate ≥1.5%
- Tiempo de retención: Reels ≥70% completed, carrusel ≥70% al último slide
- Comentarios cualitativos: preguntas de aplicación, casos compartidos
- Re-visitas al post

**Métricas blandas:**
- DMs preguntando "¿tienes más sobre esto?"
- Mención de tu post en otros perfiles
- Reducción de fricción en ventas posteriores (clientes llegan diciendo "ya apliqué tu post")

### 14.11 Errores comunes

1. Pasos vagos
2. Tutorial sin contexto del problema
3. Mucho prólogo, poca acción
4. Frameworks que son solo listas bonitas
5. Pasos imposibles para el principiante
6. No mostrar resultado
7. Vender en pieza de Transformación
8. Repetir el mismo tutorial cambiando el wrapper
9. Tutorial que requiere producto pago para empezar
10. Lenguaje técnico sin glosario

### 14.12 Cadencia recomendada

- 2–3 posts/semana, 25–30% en creadores y educadores
- Pre-lanzamiento: 35–40% durante 2–3 semanas previas
- Hora ideal: 09:00–11:00 y 18:00–20:00
- Formato dominante: Carrusel > Reel + carrusel complementario > Reel solo > video largo

---
