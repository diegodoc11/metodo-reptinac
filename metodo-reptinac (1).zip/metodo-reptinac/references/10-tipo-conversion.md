# Tipo 8 — CONVERSIÓN

*Pedir la venta directamente. Reglas matriciales de transparencia de precio. Secuencia ideal de lanzamiento de 2-3 semanas.*

---

## 18. CONVERSIÓN

### 18.1 Propósito

Conversión pide la venta. Sin medias tintas, sin insinuaciones suaves. Es la pieza donde nombras el producto, presentas la oferta, das razón para actuar ahora, y dices exactamente dónde y cómo comprar.

**Errores polares más comunes:**
- **Vendedor blando:** insinúa, espera a que la audiencia "se anime" sola.
- **Vendedor agresivo:** pitch constante, urgencia falsa, todo el feed es oferta.

Conversión bien ejecutada es directa pero merecida. Pides la venta cuando ya regalaste valor (Transformación), construiste conexión (Relacionamiento), posicionaste autoridad (Autoridad), y educaste el dolor (Niveles de Consciencia).

### 18.2 Cuándo usarlo en el embudo

- **BOFU exclusivamente:** habla a Most Aware y Product Aware.
- **Durante lanzamientos:** sube hasta 30–40% del calendario por 2–3 semanas.
- **Cadencia base permanente:** 10–15% del calendario en cuentas establecidas.

### 18.3 Las 5 sub-categorías

1. **Anuncio de apertura / lanzamiento**
2. **Urgencia y escasez** — countdowns, plazas limitadas, deadlines reales
3. **Manejo de objeciones** — pieza dedicada a responder las 3–5 objeciones más comunes
4. **Comparativa y selección** — cuando tu oferta tiene varios planes/niveles
5. **Re-engagement / segundas oportunidades** — pieza dirigida a leads tibios

### 18.4 Reglas operativas (no negociables)

1. **Precio transparente o rango claro — con excepciones** (ver sección 18.5).
2. **Urgencia y escasez REALES, nunca falsas.** Si dices "últimas 5 plazas", deben ser 5 reales.
3. **Un solo CTA por pieza.**
4. **Garantía o reducción de riesgo siempre que sea posible.**
5. **No vender productos que no encajan con tu avatar real.**
6. **Manejar al menos 2 objeciones implícitamente** en cualquier pieza.
7. **CTA directo, no eufemístico.** *"Aplica ahora"* sí; *"Hagamos magia juntos"* no.

### 18.5 Reglas de transparencia de precio

| Tipo de oferta | Mostrar precio en contenido |
|---|---|
| Productos físicos | Siempre |
| Productos digitales / cursos < $300 USD | Siempre |
| Productos digitales $300–$1.000 | Depende de posicionamiento y temperatura de audiencia |
| Programas, coaching, mentoría $1.000+ | **No mostrar.** Driving a aplicación o llamada |
| Procedimientos médicos / estéticos | **No mostrar.** Consulta de valoración primero |
| Servicios B2B custom (agencias, consultoría) | **No mostrar.** Llamada para entender alcance |
| High-ticket > $5.000 | **Nunca mostrar.** Llamada de aplicación obligatoria |

**Principio:** el precio sin contexto provoca rechazo automático. En high-ticket, lo correcto es no entregarlo hasta que haya calificación que valide que el programa encaja.

**Cómo se redacta el "no mostrar precio" sin sentirse evasivo:**
- *"La inversión está en el formulario de aplicación. Te llega después de que validemos que encajas con el programa."*
- *"No dejo el número en el post porque el precio sin contexto no te dice nada — te dice más tu situación específica y si el programa va a hacer la diferencia que buscas."*
- *"Para la inversión: aplicas, hacemos llamada de 30 min, y si encajas en el programa te paso los detalles. Si no encajas, te lo digo claro y te ahorras la duda."*

Tono: confianza profesional, no escasez fabricada.

### 18.6 Anatomía

**Movimiento 1 — Gancho con beneficio + perfil objetivo (0–3 segundos):**
- *"Para mujeres 35–45 que están cansadas de gastar en cremas que no hacen nada — abro programa de 90 días."*

**Movimiento 2 — Dolor y transformación:** anclado al Mapa de Dolores.

**Movimiento 3 — Qué incluye la oferta:** lista concreta. Módulos, sesiones, materiales, soporte, plazos.

**Movimiento 4 — Precio o rango + justificación del valor** (cuando aplica según 18.5).

**Movimiento 5 — Razón para actuar ahora:** urgencia real, escasez real, bono limitado.

**Movimiento 6 — Reducción de riesgo:** garantía, prueba, devolución, pago en cuotas.

**Movimiento 7 — CTA directo:** un solo CTA. Verbo + lugar + acción concreta.

### 18.7 Biblioteca de ganchos (20 plantillas)

1. *"Abro [N] plazas para [producto]. Si llevas tiempo dudando, este es el momento."*
2. *"Hasta el [fecha], [oferta concreta]. Después vuelve al precio normal."*
3. *"Si me has seguido durante [X tiempo] y no has dado el paso, esto es para ti."*
4. *"[Producto] está abierto. Aquí lo que incluye y para quién es."*
5. *"Última semana de [oferta]. Si te identificaste con [dolor específico], ya sabes."*
6. *"Estoy abriendo [programa]. No es para todos. Aquí los 4 criterios."*
7. *"[Programa] cierra en [tiempo]. Sin extensión. Te lo digo de una."*
8. *"Recibí [N] mensajes esta semana preguntando cuándo abro [programa]. Lo abro hoy."*
9. *"Si llevas [X tiempo] con [problema], armé esto específicamente para ti."*
10. *"Antes de comprar otro curso de [tema], lee esto."*
11. *"Bono especial para los primeros [N] que se inscriban: [bono concreto]."*
12. *"[Programa] tiene 3 niveles. Te explico cuál es para ti según tu etapa."*
13. *"Para los que están pensando 'lo voy a hacer cuando…': el cuándo es ahora."*
14. *"Mi oferta de [mes] cierra el [fecha]. Después no la repito hasta [siguiente apertura]."*
15. *"Si comentaste en [post anterior] pidiendo más sobre [tema], lo armé. Aquí está."*
16. *"Te dejo el link directo. Lo demás ya lo viste en mis posts anteriores."*
17. *"Estas son las 3 objeciones más comunes a [programa]. Te las respondo en orden."*
18. *"Si tu duda es el precio, lee este post. Si es otra, también."*
19. *"Una garantía que casi nadie ofrece en este nicho: [garantía concreta]."*
20. *"Hace [X tiempo] estaba donde tú estás ahora. Esto es lo que cambió todo."*

### 18.8 Plantilla de caption

```
[GANCHO con beneficio concreto + perfil objetivo]

[DOLOR y TRANSFORMACIÓN — anclados al Mapa de Dolores]

[QUÉ INCLUYE la oferta — específico, en bullets o párrafos cortos]

[PRECIO o RANGO + justificación del valor] (solo si aplica según 18.5)

[URGENCIA o ESCASEZ con fecha/número específico]

[GARANTÍA o reducción de riesgo]

[CTA directo y único]
```

Reglas: 200–500 palabras según formato. La audiencia que llega al final está cerca de comprar — la longitud no es enemiga, la dispersión sí.

### 18.9 Secuencia ideal de lanzamiento (2–3 semanas)

**Semana -2 (calentamiento profundo):**
- Niveles 4–3 (Problem Aware → Solution Aware)
- Relacionamiento con Banco de Auto-Aplicación conectado al producto
- 1 pieza de Polarización (postura que diferencia tu enfoque)

**Semana -1 (apuntar el cañón):**
- Niveles 2 (Product Aware) — qué hace tu producto, cómo, para quién
- Autoridad — casos, resultados, validación
- 1–2 piezas de Transformación que muestren preview del valor
- Stories con expectativa (sin abrir aún)

**Día 0 — Apertura:**
- Conversión sub-categoría 1 (Anuncio de apertura)
- Reposteo en Stories cada 4 horas el primer día
- DM personalizado a los 20–30 leads más calientes

**Días 1–4 (cierre activo):**
- Conversión sub-categoría 3 (Manejo de objeciones)
- Conversión sub-categoría 4 (Comparativa de planes, si aplica)
- Testimonios de clientes anteriores como contenido propio
- Niveles 2 reforzando producto vs. alternativas

**Días 5–7 (urgencia real):**
- Conversión sub-categoría 2 (Urgencia y escasez)
- Recordatorios diarios en Stories con countdown
- 1 Reel emotivo recordando la transformación prometida

**Día 7 — Cierre:**
- Reel de cierre con cuenta regresiva
- Stories cada hora las últimas 8 horas
- DM final a leads que mostraron interés esa semana

**Día 8 — Re-engagement:**
- Conversión sub-categoría 5 (Re-engagement) para los que dudaron
- Anuncio de cierre y siguiente cohorte

Esta secuencia disciplinada convierte 5–15% de la audiencia tibia. Ejecutada al 50% (sin secuencia), 1–3%.

### 18.10 Ejemplos completos

**Ejemplo 1 — Belleza, high-ticket (Anuncio de apertura sin precio, Carrusel 9 slides):**

Slide 1: *"Para mujeres 35–45 que llevan años gastando en cremas y procedimientos sin ver cambio real: abro 'Piel Real', mi programa de 90 días que NO incluye un solo procedimiento."*

Slide 2: *Si te miras al espejo en la mañana y la mujer que ves no se parece a la que sentías ser anoche; si has gastado más de $2.000 USD en productos en el último año sin saber cuál realmente funcionó; si tu pareja ya no te hace los comentarios que te hacía: esto NO es un programa para que te veas como tenías 25 años. Es un programa para que tu piel cuente la historia que sí es tuya.*

Slide 3: **Lo que recibes en 90 días:**
- 12 sesiones grupales de 60 min con mi equipo médico (semanales)
- Diagnóstico personalizado de tu tipo de piel
- Protocolo de productos exacto (ingredientes y marcas, sin afiliados)
- Plan nutricional integrado
- Acceso a mi DM directo durante los 3 meses
- Material grabado de por vida

Slide 4: **Lo que NO incluye:** *No vendo bótox, rellenos, ni procedimientos en clínica. No te vendo productos de una marca específica. No es un curso pasivo: si no haces el trabajo, no funciona.*

Slide 5: **Inversión:** *La información detallada va en el formulario de aplicación. No la dejo aquí porque el precio sin saber tu situación específica no te dice nada útil. Aplicas, hacemos llamada corta de 20 minutos para entender tu caso, y si el programa encaja, te paso números, formas de pago y plan de cuotas. Si no encaja, te lo digo y te ahorras tiempo.*

Slide 6: **20 plazas, abren el lunes 12, cierran el viernes 16 a las 23:59.** *No es marketing. Son 20 reales. Después abre la siguiente cohorte en 4 meses.*

Slide 7: **Garantía de 21 días.** *Si en las 3 primeras semanas sientes que el programa no es lo que esperabas, devolución completa sin preguntas.*

Slide 8: *"Llevé 8 años haciéndome procedimientos cada 3 meses. Después de los 90 días con Camila, llevo 14 meses sin un solo procedimiento y mi piel está mejor que nunca."* — Marcela R., paciente de la primera cohorte.

Slide 9: **Aplica en el link de mi bio.** *Llenas un formulario de 4 minutos. Si encajas con el perfil del programa, te llega el link de pago en menos de 24 horas.*

**Ejemplo 2 — Marketing con IA, mid-ticket (Manejo de objeciones, Carrusel 8 slides):**

Slide 1: *"Las 3 objeciones más comunes a 'Sistema IA' antes de inscribirse. Si alguna te detiene, este post es para ti."*

Slide 2: **"Ya hice cursos de IA y no me sirvieron."** *Es la objeción que más recibo. Suele ser cierta — no es que tú falles, es que esos cursos enseñan herramientas, no sistemas.*

Slide 3: *Sistema IA enseña 1 cosa: a integrar IA en TUS procesos específicos. No me importa qué herramienta usas. Resultado de los últimos 47 alumnos: 82% reportó ahorrar mínimo 8 horas semanales en los primeros 30 días.*

Slide 4: **"Estoy muy ocupado para meterme con esto ahora."** *El programa requiere 3 horas por semana durante 8 semanas. Total: 24 horas. Si llevas 6 meses "pensando en empezar con IA", probablemente ya gastaste más de 24 horas en investigación dispersa.*

Slide 5: **"$890 USD es mucha plata."** *Es plata. El precio promedio de las suscripciones que mis alumnos REVISARON antes del programa: $187 USD/mes. Lo que cancelaron después: $134 USD/mes. Ahorro anual: $1.608 USD. El programa se paga solo en 7 meses. Sin contar el aumento de productividad.*

Slide 6: **"¿Y si no me sirve?"** *30 días de garantía, devolución total. Sin preguntas. He devuelto 4 inscripciones en 2 años. Las 4 personas tenían razón en pedir devolución — no era para ellas.*

Slide 7: *Si ninguna era la tuya, probablemente la tuya sea otra distinta. Comenta abajo o escríbeme al DM y te respondo personal en menos de 12 horas.*

Slide 8: **Sistema IA — Cohorte de mayo.** Inicio: lunes 12 de mayo. Cupos: 30 (quedan 11). Inversión: $890 USD (o 3 cuotas de $325). Aplicación: link en bio.

**Ejemplo 3 — Marketing digital, high-ticket (Urgencia sin precio público, Reel 50s):**

Gancho: *"Mañana a las 23:59 cierra inscripción al Mastermind de Agencias 2026. No es marketing — es información para los que están dudando."*

> *Llevo 2 semanas posteando sobre este Mastermind. He recibido 89 mensajes preguntando detalles. De esos 89, hay 23 que están claramente listos pero llevan 6 días sin tomar la decisión.*
>
> *Si eres uno de esos 23, este Reel es para ti.*
>
> *El Mastermind tiene 12 plazas. Quedan 4. Mañana a las 23:59 cierran. No abro extensión. No abro lista de espera con prioridad.*
>
> *Por qué soy estricta: porque la calidad del Mastermind depende de que el grupo se forme rápido y empecemos. Si extiendo, retraso el inicio para los que ya pagaron. No es justo.*
>
> *Si tu duda es la inversión: la información completa va en el formulario de aplicación. Llena las 8 preguntas, en menos de 24 h te llega respuesta. Si encajas, te paso el detalle de inversión y formas de pago. Si no encajas, te lo digo claro y te ahorras meses de duda.*
>
> *Si tu duda es el tiempo: 3 horas semanales durante 6 meses. Sábados de 9 a 12 AM hora Bogotá. Si no puedes esos sábados, no apliques.*
>
> *Mañana 23:59. Link en bio.*

**Ejemplo 4 — Coaching seducción (Re-engagement, Reel 60s):**

Gancho: *"Si me sigues hace más de 6 meses y aún no has trabajado conmigo, este Reel es específicamente para ti."*

> *Voy a ser directo. Tengo en mi DM mensajes de hace 8, 10, 14 meses de hombres que escribieron preguntando cómo aplicar al programa. Algunos respondieron mis preguntas iniciales y luego desaparecieron. Otros pidieron tiempo para "pensarlo".*
>
> *No los juzgo. Yo también soy de los que postergan decisiones difíciles.*
>
> *Pero quiero decirte algo: si llevas 6, 12, 18 meses siguiéndome sin dar el paso, es muy probable que haya algo más profundo que la duda intelectual sobre el programa. Probablemente es miedo. Miedo a que esto tampoco funcione. Miedo a empezar y descubrir que el problema es más grande. Miedo a invertir en ti mismo otra vez después de [otros intentos].*
>
> *Te entiendo. Y por eso voy a hacer algo distinto este mes.*
>
> *Hasta el 31, abro 5 sesiones diagnósticas gratuitas — 45 minutos, 1 a 1, sin compromiso. Si después decides aplicar, perfecto. Si decides que no es para ti, perfecto también. La sesión es genuinamente para diagnosticar tu situación, no para venderte.*
>
> *Solo 5 sesiones. Solo para los que llevan más de 6 meses siguiéndome y NO han trabajado conmigo. Si eres nuevo en mi cuenta, esta no es para ti.*
>
> *Para aplicar: comenta "Diagnóstico" en este Reel. Te respondo personalmente al DM con un formulario de 5 preguntas. Las primeras 5 que apliquen y encajen, agendamos.*

### 18.11 KPIs y métricas

**Métricas duras:**
- Tasa de conversión por pieza ≥ 0.5% en orgánico, ≥ 2% en pauta
- Click-through rate al link ≥ 2% en orgánico
- DM-to-sale ratio
- ROAS si usas pauta
- Cart abandonment recovery rate

**Métricas blandas:**
- Velocidad de cierre (tiempo desde primer DM hasta venta)
- Calidad de objeciones recibidas (más sofisticadas = mejor educación previa)
- Tasa de retorno de leads tibios reactivados

### 18.12 Errores comunes

1. Vender sin haber calentado (Niveles de Consciencia ausente)
2. No nombrar precio cuando corresponde mostrarlo (low/mid-ticket)
3. Mostrar precio cuando NO corresponde (high-ticket)
4. Urgencia falsa
5. Múltiples CTAs
6. No anticipar objeciones
7. Mezclar Conversión con Transformación
8. Conversión todo el feed (>20%)
9. Sin diferenciación de la oferta
10. Sin garantía o reducción de riesgo
11. Vender productos que no encajan con el avatar
12. CTA eufemístico

### 18.13 Cadencia recomendada

- Cadencia base: 10–15% del calendario (1 pieza/semana)
- Pre-lanzamiento (2 semanas): 0% (solo Niveles de Consciencia y Autoridad)
- Lanzamiento activo (1–2 semanas): 30–40%
- Post-lanzamiento (1 semana): 5% (Re-engagement)
- Hora ideal: 09:00–11:00 y 19:00–21:00
- Formato dominante: Carrusel + Reel a cámara complementario > Reel a cámara solo > carrusel solo

---
