# Anexo D — Glosario de Términos del Método

*Definiciones de los términos clave: anchor de credibilidad, banco de auto-aplicación, CTA filtrante, mapa de dolores, niveles de consciencia, modos de polarización, save rate, test de amenaza concreta, etc.*

---

## ANEXO D — Glosario de términos del método

**Anchor de credibilidad:** primer movimiento de un post de Autoridad. Métrica, dato, mención que ancla la legitimidad de quien habla.

**Avatar:** cliente ideal específico, definido en sección C del Brief.

**Banco de Auto-Aplicación:** lista de mínimo 8 momentos donde lo que vendes te ayudó a ti. Cada momento genera 4 piezas de contenido (Relacionamiento + Autoridad + Niveles de Consciencia + Conversión).

**BOFU (Bottom of Funnel):** etapa final del embudo. Lead caliente, listo para comprar.

**Brief de Marca / Story Bank:** documento maestro de 15 secciones que alimenta todo el método.

**CTA filtrante:** llamado a la acción que invita solo al perfil específico. Convierte 3–6% vs. 0.5–1% del CTA genérico.

**CTA de lead magnet por DM:** invitación a comentar palabra clave para recibir recurso gratuito por mensaje directo. CTA más rentable de Transformación.

**Engagement filtrante:** Engagement que no busca volumen ciego, sino retención de perfil ideal.

**Mapa de Creencias del Nicho:** sección N del brief. Combustible para Polarización.

**Mapa de Dolores:** sección O del brief. 4 niveles × 5+ dolores cada uno = mínimo 20 dolores.

**MOFU (Middle of Funnel):** etapa intermedia. Lead consciente del problema, evaluando soluciones.

**Modo episódico (Polarización):** una postura confrontacional distinta cada vez. 1–2/mes.

**Modo sostenido (Polarización):** martilleo a una práctica específica con ángulos distintos. Hasta 1/semana con condiciones estrictas.

**Niveles de Consciencia (Schwartz):** 5 niveles del prospecto: Unaware, Problem Aware, Solution Aware, Product Aware, Most Aware.

**Niveles de Dolor (REPTINAC):** 4 niveles del Mapa de Dolores: externo, interno, relacional, filosófico.

**Pieza:** unidad de contenido (post, Reel, carrusel, Story).

**REPTINAC:** acrónimo de los 8 tipos: Relacionamiento, Engagement, Polarización, Transformación, Interacción 1×1, Niveles de Consciencia, Autoridad, Conversión.

**Save rate:** % del alcance que guarda el post. Indicador #1 de calidad en Transformación y Autoridad.

**Sub-categoría:** subdivisión dentro de cada uno de los 8 tipos. Cada tipo tiene 5–6 sub-categorías.

**Test de Amenaza Concreta:** filtro para dolores filosóficos. Un dolor filosófico válido tiene consecuencia material y horizonte temporal específicos.

**TOFU (Top of Funnel):** etapa inicial del embudo. Audiencia fría o nueva.
