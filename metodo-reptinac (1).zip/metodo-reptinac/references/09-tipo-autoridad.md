# Tipo 7 — AUTORIDAD

*Justificar derecho a cobrar lo que cobras. Diferencia entre Autoridad bien y mal ejecutada. Casos, insights, prensa.*

---

## 17. AUTORIDAD

### 17.1 Propósito

Autoridad justifica tu derecho a cobrar lo que cobras y a decir lo que dices. Mientras Relacionamiento muestra quién eres, Autoridad responde la pregunta silenciosa que se hace todo lead antes de comprar: *"¿por qué esta persona y no otra?"*.

Autoridad no es exhibirse. Es construir, pieza a pieza, una **arquitectura de credibilidad** que haga que tu posición en el mercado sea defendible y obvia. Cuando esa arquitectura está construida, el precio deja de ser objeción y los clientes llegan calificados.

**Lo que Autoridad NO es:**
- Lista de logros sin contexto.
- Presumir títulos sin sustancia.
- Relacionamiento disfrazado.

### 17.2 Cuándo usarlo en el embudo

- **MOFU avanzado y BOFU temprano:** funciona mejor con base de Relacionamiento + Transformación previa.
- **Antes de un lanzamiento (Día -7 a -3):** semana clave para depositar credibilidad.
- **Para justificar subida de precios.**
- **En crisis de marca o industria:** cuando hay duda generalizada sobre tu nicho.

### 17.3 Las 5 sub-categorías

1. **Credenciales y trayectoria** — años, certificaciones, formaciones, proyectos destacados.
2. **Estudios de caso propios** — cliente, contexto, estrategia, resultados con métricas.
3. **Menciones, prensa y eventos** — features en medios, entrevistas, conferencias.
4. **Insights y análisis sectoriales** — análisis de tendencias, predicciones, perspectiva basada en data propia.
5. **Investigaciones y materiales premium** — whitepapers, ebooks, reportes propios.

### 17.4 La diferencia entre Autoridad bien y mal ejecutada

**Mal ejecutada:**
- Lista de logros sin marco interpretativo (CV en formato post)
- Foto en evento sin explicar qué insight te llevaste
- "Trabajé con 200 clientes" sin QUÉ aprendiste
- Caso con métrica sin contexto

**Bien ejecutada:**
- Logro + lección extraíble para la audiencia
- Evento + 3 ideas que aplicarás
- "200 clientes en sector belleza en LATAM, este patrón vi en el 60%"
- Caso completo: punto de partida + estrategia + obstáculos + resultado + lección generalizable

**Diferencia mecánica:** la Autoridad mal ejecutada habla de ti; la Autoridad bien ejecutada habla del trabajo a través de ti.

### 17.5 Anatomía

**Movimiento 1 — Anchor de credibilidad (0–3 segundos):** métrica, dato, mención, proyecto que ancle al lector.
- *"He revisado 89 funnels de agencias colombianas en los últimos 18 meses…"*
- *"En 12 años haciendo medicina estética he atendido a más de 3.400 pacientes…"*

**Movimiento 2 — Contexto/marco:** qué hace que esta autoridad sea pertinente al tema.

**Movimiento 3 — Sustancia (la pieza real):** caso, análisis, métricas, datos. 70% del peso.

**Movimiento 4 — Insight diferenciador:** la conclusión que solo alguien con tu experiencia podría sacar.

**Movimiento 5 — CTA hacia más profundidad:** descarga, suscripción, conversación 1×1. Autoridad rara vez vende directo.

### 17.6 Biblioteca de ganchos (20 plantillas)

1. *"He trabajado con [N] [tipo de cliente] en los últimos [tiempo]. Esto es lo que aprendí."*
2. *"Caso de estudio: cómo [cliente] pasó de [estado A] a [estado B] en [tiempo]."*
3. *"Llevo [N] años en [campo] y nunca había visto algo como esto."*
4. *"Acabo de salir de [evento/conferencia]. Tres cosas que me llevo."*
5. *"Mi análisis del último cambio en [tendencia/algoritmo/regulación]:"*
6. *"Datos de [N] [campañas/proyectos/casos] que ejecuté en [periodo]:"*
7. *"[Medio reconocido] me citó la semana pasada. Te cuento el contexto."*
8. *"He revisado [N] [casos/datos] en los últimos meses. El patrón es claro:"*
9. *"Mi predicción para [próximos meses]: y por qué."*
10. *"Acabo de publicar mi reporte anual sobre [tema]."*
11. *"Hablé con [N] [profesionales reconocidos] esta semana. Lo que coinciden:"*
12. *"Después de [N] años en esto, sigo aprendiendo. Esta semana:"*
13. *"En la conferencia de [evento] el tema dominante fue X. Y pocos lo notaron."*
14. *"Análisis de mi último año: [dato comparativo]. Aquí lo que cambió y por qué."*
15. *"Si revisas mi proceso de los últimos [tiempo], hay un patrón:"*
16. *"[Empresa/Persona reconocida] aplicó X en su última campaña. Mi lectura:"*
17. *"Patrones en [N] [proyectos] del último trimestre que nadie está nombrando:"*
18. *"Después de auditar [N] [tipo de proyecto], la causa #1 de fracaso es:"*
19. *"Mi tesis sobre el futuro de [industria] en los próximos 3 años:"*
20. *"Esto es lo que [N] de mis mejores clientes tienen en común:"*

### 17.7 Plantilla de caption

```
[ANCHOR de credibilidad — métrica, mención, dato concreto]

[CONTEXTO — por qué esto importa para tu audiencia]

[SUSTANCIA — caso, análisis, datos]

[INSIGHT diferenciador — la lectura que solo tú puedes ofrecer]

[CTA hacia más profundidad — descarga, suscripción, conversación]
```

Reglas: 200–500 palabras. Autoridad pide densidad y especificidad.

### 17.8 Ejemplos completos

**Ejemplo 1 — Belleza (Estudio de caso, Carrusel 8 slides):**

Slide 1: *"3.400 pacientes en 12 años. Y aún así, este caso me sorprendió."*

Slide 2: *Mariana llegó a mi clínica en marzo de 2024 con diagnóstico de "rosácea idiopática" después de 6 años con 4 dermatólogos diferentes. Tomaba 3 medicamentos sistémicos, había gastado más de $4.000 USD en cremas y procedimientos, y su piel estaba peor.*

Slide 3: *En lugar de prescribir nuevo tratamiento, le pedí 4 cosas: suspender 2 de las 3 cremas (interactuaban entre sí), hacer panel hormonal completo, suspender lácteos por 6 semanas como prueba, una sola cita semanal para evaluar progreso.*

Slide 4: *El panel reveló disregulación hormonal post-DIU. La rosácea no era idiopática — era manifestación cutánea de algo que ningún dermatólogo había mirado. 6 semanas después, inflamación bajó 70%. 4 meses después, sin medicación sistémica, rutina de 4 productos.*

Slide 5: **Antes (diciembre 2023):** *3 medicamentos, 7 productos tópicos, 8 citas/año, gasto mensual $380 USD.* **Después (octubre 2024):** *0 medicamentos, 4 productos tópicos, 2 citas/año, gasto mensual $95 USD.*

Slide 6: *Lo que pasó con Mariana no es excepcional. En los últimos 4 años he visto al menos 23 casos similares: pacientes con diagnóstico cutáneo "idiopático" que en realidad eran síntomas hormonales, intestinales o de carga inflamatoria sistémica.*

Slide 7: *El problema no es la dermatología. Es la fragmentación de la medicina. La piel reporta lo que pasa adentro — y el adentro no está en el currículo de la mayoría de los especialistas en piel.*

Slide 8: *Si tienes condición cutánea persistente que no responde a tratamiento dermatológico estándar después de 12 meses, exige panel hormonal y revisión digestiva ANTES de aceptar otro tratamiento de superficie.*

CTA: *"Caso completo (con permiso de Mariana, sin datos identificables) disponible en mi blog. Link en bio."*

**Ejemplo 2 — Marketing con IA (Insight estratégico, Carrusel 7 slides):**

Slide 1: *"He auditado 47 estrategias de IA aplicada a marketing en los últimos 6 meses. La causa #1 de fracaso no es la que crees."*

Slide 2: *Entre noviembre 2025 y abril 2026 acompañé a 47 negocios. Tamaños desde solopreneurs hasta equipos de 30. El 71% reportaba haber gastado entre $5.000 y $40.000 USD en herramientas + capacitación, y NO tener retorno medible.*

Slide 3: *La hipótesis común: "falta más training", "las herramientas no son las correctas", "el equipo se resiste".*

Slide 4: *Ninguna de las 3 era la causa principal en mis 47 casos. La causa #1 (38 de 47): NO HABÍAN DEFINIDO QUÉ PROCESO DE NEGOCIO ESTABAN INTENTANDO MEJORAR. Estaban "implementando IA" como si IA fuera el objetivo, no la herramienta.*

Slide 5: *En los 38 casos: suscripciones promedio 8 herramientas IA simultáneas. Procesos definidos para cada herramienta: 1.4 en promedio. Por lo tanto: 6.6 herramientas pagándose sin función operativa clara.*

Slide 6: *En los 23 casos donde aplicamos remediación: paso 1, definir 1 proceso operativo crítico. Paso 2, elegir 1 herramienta. Paso 3, workflow detallado durante 30 días sin variación. Paso 4, medición y refinamiento. Resultado promedio en 90 días: 14 horas/semana liberadas, $230 USD/mes recuperados.*

Slide 7: *La mayoría de profesionales no necesitan "más IA". Necesitan "menos IA mejor aplicada". El mercado los empuja en dirección opuesta porque hay más vendedores de herramientas que diagnosticadores de procesos.*

CTA Reel cierre: *"Reporte completo con los 47 casos analizados — gratis, link en bio. Es 38 páginas con datos, patrones y framework de remediación."*

**Ejemplo 3 — Marketing digital (Mención de prensa, Reel 75s):**

Gancho: *"Forbes Centroamérica me citó la semana pasada en su reporte sobre agencias digitales emergentes. Te cuento el contexto y la idea que aporté."*

> *En enero, Forbes Centroamérica empezó un especial sobre el estado de las agencias digitales en LATAM. Me contactaron porque vieron mi LinkedIn donde llevo dos años publicando análisis de cierre de campañas con datos reales.*
>
> *La pregunta que me hicieron: "¿Por qué muchas agencias colombianas y mexicanas, fundadas entre 2018 y 2022, están cerrando ahora a pesar de que el mercado sigue creciendo?"*
>
> *Mi respuesta — la que terminó publicada — fue esta: "Las agencias que cerraron eran agencias generalistas en un mercado que ya no premia generalismo. Entre 2018 y 2022 se podía construir agencia diciendo 'hacemos pauta + redes + diseño + email'. En 2025 el cliente exige especialización profunda en UN canal, con data y metodología demostrable. Las que no se especializaron a tiempo, ya cerraron o están a punto."*
>
> *El reporte completo de Forbes salió la semana pasada. Lo más interesante para mí no es la cita — es la confirmación con data agregada que ellos obtuvieron: el 47% de las agencias generalistas fundadas entre 2018 y 2022 en LATAM cerraron entre 2023 y 2025. El 9% de las especializadas. La diferencia es brutal.*
>
> *Si llevas agencia generalista, esto no es para asustarte. Es para que decidas tu vertical antes de que el mercado decida por ti.*

**Ejemplo 4 — Coaching seducción (Patrones observados, Reel 90s):**

Gancho: *"He acompañado a 187 hombres en los últimos 5 años. Te voy a contar el factor #1 que separa a los que transforman su vida amorosa en menos de un año de los que siguen igual después de 3."*

> *Voy a ser directo: este patrón es contraintuitivo y va a contradecir lo que enseña casi cualquier coach de mi nicho. Pero los datos de 187 alumnos no mienten.*
>
> *El factor #1 NO es: atractivo físico, edad, estatus, cantidad de "técnicas" aprendidas, ni carisma natural. (Los introvertidos transformaron más rápido en promedio.)*
>
> *El factor #1 ES: la cantidad de tiempo solitario semanal que el hombre tiene contemplado en su rutina antes de empezar el programa.*
>
> *Hombres con menos de 5 horas semanales de actividad solitaria significativa (lectura, deporte individual, hobbies, journaling) tardaron en promedio 2.3 veces más en ver cambio sostenible que hombres con 10+ horas.*
>
> *Por qué: el problema afectivo casi siempre es síntoma de una identidad construida hacia afuera. El hombre que llena cada hueco con estímulo externo (redes, gym social, salidas, trabajo intenso) no ha desarrollado la base interna desde donde se construye atractivo real.*
>
> *Conclusión: si llevas tiempo trabajando en tu vida amorosa sin avance sostenible, antes de invertir en otro programa, pregúntate: ¿cuántas horas a la semana estás verdaderamente contigo mismo, sin estímulo? Si la respuesta es menos de 5, ese es el primer trabajo. Sin él, ningún otro funciona.*

CTA: *"Si te resonó, comenta 'Tiempo solo' y te envío por DM una guía corta sobre cómo construir esa base — sin venta, gratis."*

### 17.9 KPIs y métricas

**Métricas duras:**
- Saves rate ≥ 3% del alcance
- Time on post: carrusel ≥70% al último slide; Reels ≥75% completed
- Mentions/citas en contenido de otros (con o sin tag)
- DMs cualificados ("vi tu análisis sobre X y…")
- Clics a recursos premium

**Métricas blandas:**
- Invitaciones a podcasts, eventos, charlas
- Disminución de objeciones por precio en llamadas de venta
- Aparición de tu trabajo en threads y discusiones del nicho
- Reducción del ciclo de venta

### 17.10 Errores comunes

1. Lista de logros sin marco interpretativo
2. Casos sin métricas comparativas
3. Mencionar prensa sin agregar valor
4. Autoridad disconectada del avatar
5. Insight sin rigor
6. Tono pomposo
7. Confundir Autoridad con Conversión
8. No actualizar credenciales (>6 meses)
9. Solo Autoridad en el feed (frío)
10. Inflar credenciales o casos
11. Mencionar a clientes sin permiso

### 17.11 Cadencia recomendada

- 15–20% del calendario en cuentas establecidas; 10% en cuentas nuevas
- Pre-lanzamiento (semana -1 a -7): sube a 25–30%
- Hora ideal: 09:00–12:00 y 19:00–21:00
- Formato dominante: Carrusel denso > Reel a cámara con análisis hablado > foto + caption largo

---
