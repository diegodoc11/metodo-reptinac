# Tipo 5 — INTERACCIÓN 1×1

*Convertir espectadores en interlocutores. Reglas operativas (compromiso de respuesta, AMA, cajas de preguntas).*

---

## 15. INTERACCIÓN 1×1

### 15.1 Propósito

Interacción 1×1 convierte espectadores en interlocutores. Mientras todos los otros tipos son broadcast, este es diálogo: tú abres una invitación, la audiencia responde, tú vuelves a responder. La métrica que importa no es alcance ni saves — es **calidad y profundidad de conversación**.

### 15.2 Cuándo usarlo en el embudo

- **Cualquier etapa, especialmente MOFU:** convierte seguidor en miembro activo.
- **Antes de un lanzamiento (BOFU):** una semana de Interacción intensiva pre-venta da el termómetro real de objeciones.
- **Después de pieza fuerte de Polarización o Transformación:** abre espacio para procesar lo publicado.

### 15.3 Las 6 sub-categorías

1. **Preguntas abiertas en feed/Reel** — pieza cuyo propósito es generar comentarios cualitativos.
2. **Cajas de preguntas en Stories** — espacio efímero (24 h) para recibir y responder.
3. **Polls, quizzes y sliders en Stories** — interacción de un toque.
4. **AMA en Stories o Live** — sesión programada de preguntas y respuestas.
5. **Respuestas públicas a comentarios convertidas en post** — toma un comentario destacado y respóndelo en formato post o Reel.
6. **Compilaciones de FAQ** — recopilación mensual.

### 15.4 Reglas operativas (no negociables)

1. **Compromiso de respuesta en ≤ 4 horas** a todo comentario cualitativo.
2. **Bloque dedicado:** mínimo 30 min al día reservados solo para responder.
3. **Cajas de preguntas:** abrir y responder dentro de 24 h.
4. **AMA en vivo:** estructura básica + improvisación. Anunciar 24 h antes.
5. **Compartir DMs sin permiso = prohibido.**
6. **Respuestas genéricas o copiadas = prohibido.** Una respuesta de 2 líneas específica vale 10 veces una de 6 líneas plantillada.
7. **No mostrar favoritismo descarado.**

Sin estas reglas, Interacción 1×1 se convierte en simulación de cercanía.

### 15.5 Anatomía

**Movimiento 1 — Invitación clara y específica:** pregunta concreta, NO genérica.
- ❌ *"¿Cuál es tu mayor reto?"*
- ✅ *"¿Cuál es la objeción más frecuente que recibes cuando ofreces tu servicio premium?"*

**Movimiento 2 — Contexto que facilita la respuesta:** una o dos líneas que enmarcan.

**Movimiento 3 — Pista de respuesta esperada (opcional):** *"Te leo. Puede ser tan simple como una palabra o tan largo como tres párrafos."*

**Movimiento 4 — Promesa de acción posterior:** *"Te respondo a todos en las próximas horas."* o *"Las 5 mejores preguntas las respondo en un Reel mañana."*

### 15.6 Biblioteca de ganchos (20 plantillas)

1. "Cuéntame en comentarios: ¿cuál es tu mayor [reto/duda/objeción] sobre [tema específico]?"
2. "Caja de preguntas abierta por 24 horas. Lánzame todo sobre [tema] y respondo en orden."
3. "AMA programado: [día y hora]. Pregúntame lo que quieras sobre [área específica]."
4. "Voto rápido: ¿prefieres [A] o [B]?"
5. "@usuario, tu pregunta merece su propio post. Aquí va la respuesta."
6. "Top 5 preguntas más repetidas esta semana en mis DMs:"
7. "Etiquétame en tu Story con tu duda y la respondo ahí mismo."
8. "¿Qué tema quieres que cubra esta semana? Te leo y elijo el más votado."
9. "Necesito tu input: estoy decidiendo entre [A] y [B]."
10. "Lanza tu mayor objeción sobre [práctica/idea] y la trabajo en comentarios."
11. "Mini-consulta gratis: comenta tu situación específica y te doy un tip personalizado."
12. "Test rápido: ¿en qué etapa de [proceso] estás? Comenta el número."
13. "¿Cuál fue tu mayor [logro/aprendizaje/error] esta semana?"
14. "Cuéntame algo sobre ti que no se note en mi feed."
15. "¿Verdadero o falso? [afirmación controvertida del nicho]"
16. "Encuesta: ¿estás a favor o en contra de [práctica de la industria]?"
17. "Comenta el emoji que mejor describe cómo te sientes con [tema]."
18. "Rellena: 'Mi mayor frustración con [tema] ahora mismo es ___'"
19. "Stories abiertas las próximas 24 h para tus preguntas. Sin tabúes."
20. "Comparte tu mayor victoria del mes. Las 3 mejores van a mi Story con tu permiso."

### 15.7 Plantilla de caption

```
[INVITACIÓN clara y específica]

[CONTEXTO que enmarca la pregunta — 1-2 líneas]

[EJEMPLO o pista de respuesta esperada — opcional]

[PROMESA de acción posterior]
```

Reglas: caption ≤ 80 palabras. Debe leerse en 10 segundos.

### 15.8 Ejemplos completos

**Ejemplo 1 — Belleza (Respuesta pública convertida en Reel, 40s):**

Contexto: comentario destacado anterior — *"Doctora, ¿esto sirve igual si tengo piel mixta?"*

> *Esta pregunta me la hicieron 14 veces ayer. Es tan buena que merece su propio post.*
>
> *Ana, la rutina base sí funciona. La diferencia con piel mixta es 2 ajustes:*
>
> *Uno, el limpiador. Si tu zona T se siente grasosa al despertar, usa un limpiador con ácido salicílico al 0.5%, 3 veces por semana. No diario.*
>
> *Dos, el hidratante. En zona T usa textura gel; en mejillas, textura crema. Mismo producto en distinto tipo NO funciona. Es la única rutina del mundo donde la cara se trata por zonas.*
>
> *Y si tu doctora no te lo dijo, te tocó el modelo perezoso.*
>
> *Ana, gracias por la pregunta. Y al resto: si tienen dudas específicas como esta, comenta abajo y voy respondiendo en serie.*

**Ejemplo 2 — Marketing con IA (Caja de preguntas + compilación FAQ):**

Día 1 (Story): *"Caja de preguntas abierta por 24 horas. Pregúntame cualquier cosa sobre IA aplicada a marketing. Sin filtro. Mañana las top 5 las respondo en carrusel."*

Día 2 (Carrusel 7 slides): compilación de las 5 preguntas más repetidas + respuestas concretas de 60–100 palabras cada una.

**Ejemplo 3 — Marketing digital (AMA en Live programado):**

Día -2: anuncio en feed con tema específico ("cómo vender servicios premium sin pelear precios").
Día 0 mañana: caja de preguntas en Stories recolecta 30–60 preguntas.
Día 0 7 PM: Live de 45 min — 5 min intro + 30 min respondiendo + 5 min preguntas en vivo + 5 min cierre.
Día +1: carrusel con 4 mejores preguntas/respuestas + link al replay.

**Ejemplo 4 — Coaching seducción (Pregunta abierta, Reel 30s):**

Gancho: *"Te voy a hacer una pregunta y te pido que la contestes con honestidad — aunque no la firmes."*

> *Cuando ves a una mujer que te gusta en un lugar público y NO te acercas — no me digas qué te dijiste para justificarlo. Dime qué SENTISTE en el cuerpo.*
>
> *¿Cosquilleo? ¿Frío? ¿Pecho apretado? ¿Mareo? ¿Mente en blanco?*
>
> *Eso me interesa. Porque las técnicas no se entrenan, se entrenan las respuestas corporales. Y el primer paso es saber cuál es la tuya.*
>
> *Comenta abajo. Puedes responder con UNA palabra. O con seis. No te voy a juzgar, voy a usar tus respuestas para preparar el contenido de la próxima semana.*

### 15.9 KPIs y métricas

**Métricas duras:**
- Tasa de respuesta del creador: ≥90% de comentarios cualitativos respondidos
- Tasa de respuesta de la audiencia: ≥1% del alcance
- Comentarios de retorno (usuarios que vuelven a comentar)
- DMs cualitativos generados
- Visualización de Stories con caja de preguntas: ≥30% del audience size

**Métricas blandas:**
- Profundidad de respuestas (longitud promedio)
- Aparición de preguntas inteligentes
- Conversión de DM a llamada/sesión
- Reducción del "tiempo de incubación" entre primer contacto y compra

### 15.10 Errores comunes

1. Publicar pregunta y no responder
2. Preguntas demasiado abiertas o genéricas
3. AMA sin estructura
4. Respuestas plantilladas
5. Favoritismo descarado
6. Compartir DMs sin permiso
7. Hacer Live sin promoción
8. Convertir TODO en pregunta
9. Responder con CTA de venta directa
10. Ignorar críticas legítimas
11. Cajas de preguntas sin tema definido

### 15.11 Cadencia recomendada

- 1–2 piezas explícitas/semana
- Stories: polls/preguntas 3–5 veces/semana
- AMA o Live: 1–2/mes
- Compilación FAQ: 1/mes
- Bloque diario de respuesta: 30 min no negociables
- Hora ideal: 11:00–13:00 y 19:00–21:00
- Formato dominante: Stories > carrusel > Reel > Live > foto

---
