---
name: metodo-reptinac
description: Método REPTINAC para creación de contenido de marcas, negocios e infoproductos con 8 tipos de contenido. Actívalo siempre que el usuario pida contenido para redes (Instagram, Reels, carruseles), calendario editorial, copy de marca, estrategia editorial, posts virales, contenido de venta, secuencia de lanzamiento, o consulte sobre algún cliente, marca personal, negocio local, agencia o infoproducto.
---

# Método REPTINAC

Sistema completo de creación de contenido editorial estructurado en **8 tipos complementarios**, cada uno con propósito específico dentro del embudo de marketing y el recorrido mental del prospecto.

El acrónimo:
- **R**elacionamiento
- **E**ngagement
- **P**olarización
- **T**ransformación
- **I**nteracción 1×1
- **N**iveles de Consciencia
- **A**utoridad
- **C**onversión

Una marca saludable rota entre los 8 según su etapa, su nicho y su momento comercial.

---

## Cuándo activar este skill

Actívalo en cualquiera de estos escenarios:

- Petición directa: *"hazme un post de…"*, *"escribe un Reel para…"*, *"necesito contenido para Instagram de…"*
- Estrategia editorial: *"arma calendario semanal/mensual"*, *"distribución de contenidos"*, *"qué publicar esta semana"*
- Lanzamientos: *"prepara lanzamiento"*, *"secuencia de venta"*, *"campaña de apertura"*
- Diagnóstico editorial: *"revisa mi feed"*, *"qué le falta a mi contenido"*, *"por qué no convierte"*
- Briefs de marca: *"define avatar"*, *"mapa de dolores"*, *"banco de historias"*
- Copywriting de marca: *"copy de bio"*, *"caption para…"*, *"gancho para Reel"*

Si el usuario menciona el nombre del método ("Método REPTINAC", "los 8 tipos", "el método") activación es obligatoria.

---

## Los 8 tipos de un vistazo

| Tipo | Propósito | Embudo | % típico |
|---|---|---|---|
| Relacionamiento | Conexión emocional y confianza | TOFU/MOFU | 15–20% |
| Engagement | Alcance bruto y algoritmo | TOFU | 20–30% |
| Polarización | Diferenciación confrontacional | MOFU | 5–10% |
| Transformación | Enseñar habilidades concretas | MOFU | 20–25% |
| Interacción 1×1 | Diálogo directo | Transversal | 5–10% |
| Niveles de Consciencia | Mover prospecto en su escalera mental | Todo | 25–30% |
| Autoridad | Justificar precio/posición | MOFU/BOFU | 10–15% |
| Conversión | Pedir la venta directamente | BOFU | 10–15% |

Cada tipo tiene capítulo propio en `references/`. Carga el capítulo correspondiente cuando vayas a generar una pieza de ese tipo.

---

## Protocolo de configuración inicial (PRIMERA VEZ con un negocio/cliente)

Antes de generar cualquier pieza para un negocio o cliente nuevo, ejecuta los 6 pasos. Sin estos inputs, el método produce contenido genérico — y eso es exactamente lo que NO buscamos.

**Paso 1 — Brief de Marca:**
Pregunta al usuario:
> *"¿Quieres llenar el Brief en modo libre (cuéntame tu historia como a un amigo) o en modo estructurado (preguntas sección por sección)?"*

- Modo libre: recibe el relato, identifica secciones cubiertas, dispara 3–5 preguntas puntuales para llenar huecos.
- Modo estructurado: ejecuta las 15 secciones del brief en orden.

Carga `references/02-brief-y-mapas.md` para el detalle de las 15 secciones.

**Paso 2 — Tipo de negocio y etapa de cuenta:**
- *"¿Qué tipo de negocio?"* (marca personal high-ticket / negocio local / e-commerce / B2B / creador de contenido / infoproducto)
- *"¿En qué etapa está la cuenta?"* (nueva <10K / crecimiento / establecida >50K / lanzamiento activo)
- *"¿Hay lanzamiento próximo?"* (sí/no, fecha si sí)

Esto carga la matriz de proporciones correcta. Carga `references/11-arquitectura-calendario.md` cuando el usuario pida calendario.

**Paso 3 — Banco de Auto-Aplicación (sección H del brief):**
Pide mínimo 8 momentos en los últimos 24 meses donde lo que el usuario vende le ayudó a sí mismo. Para cada momento: cuándo, situación, qué aplicó, cómo le fue, qué le diría a un cliente que duda.

Si el usuario tiene menos de 8, asistirlo con preguntas para extraerlos. Sin el Banco de Auto-Aplicación, Relacionamiento y Niveles de Consciencia producen contenido frío.

**Paso 4 — Mapa de Dolores del Avatar (4 niveles):**
- *"¿Tienes los dolores del avatar mapeados en 4 niveles (externo, interno, relacional, filosófico)?"*
- Si sí: el usuario los pega.
- Si no: genera propuesta de 4 niveles × 5+ dolores cada uno (mínimo 20 dolores).

**Regla crítica para dolores filosóficos:** todos deben pasar el **Test de Amenaza Concreta**: ¿qué le pasa a esta persona, en cuánto tiempo, si no resuelve esto? Si el dolor filosófico es pregunta abstracta sin consecuencia material y horizonte temporal, reescríbelo. *"¿Qué significa ser útil en una era de IA?"* (débil) → *"Si no domino IA en los próximos 12 meses, alguien que sí la domine va a hacer mi trabajo por la mitad de lo que cobro"* (fuerte).

Carga `references/02-brief-y-mapas.md` y `references/13-anexo-mapa-dolores-ejemplos.md`.

**Paso 5 — Naturaleza de la oferta principal:**
- *"¿Cuál es la oferta principal y su rango de precio?"*
- Opciones: producto físico / digital low-ticket / digital mid-ticket / programa o coaching $1.000+ / procedimiento médico/estético / servicio B2B custom / high-ticket >$5.000.

Esto activa la regla de transparencia de precio para Conversión (ver `references/10-tipo-conversion.md`).

**Paso 6 — Mapa de creencias del nicho (sección N del brief):**
Mitos populares, verdades incómodas, prácticas saturadas, enfoques con los que NO está de acuerdo. Si va a usar Polarización en modo sostenido, definir tesis central. Carga `references/05-tipo-polarizacion.md`.

**Sin estos 6 pasos completados, el skill no genera contenido — pide completar el paso faltante y explica por qué.**

Una vez completado el protocolo, los inputs quedan disponibles para todas las generaciones de la conversación. Si la conversación cambia de cliente/marca, el protocolo se reinicia.

---

## Workflow de generación de una pieza

**Paso A — Decidir el tipo de contenido.**

Pregunta o decide según contexto:
- ¿El usuario explicitó qué tipo? (*"hazme un Reel de Polarización"*) → usar ese.
- ¿El usuario dio un objetivo? (*"quiero alcance"* → Engagement; *"vender el programa"* → Conversión).
- ¿No hay claridad? Ofrece 2–3 opciones de tipo justificadas: *"Para tu objetivo X, los tipos que mejor calzan son: Y porque…, Z porque… ¿Cuál prefieres?"*

**Paso B — Cargar el capítulo correspondiente.**

Antes de generar, carga el archivo `references/0X-tipo-[nombre].md` correspondiente. Cada capítulo tiene:
- Sub-categorías del tipo
- Anatomía (movimientos)
- Biblioteca de 20 ganchos
- Plantilla de caption rellenable
- 4 ejemplos completos en 4 nichos
- KPIs específicos
- Errores comunes
- Cadencia recomendada

**Paso C — Elegir sub-categoría y formato.**

Dentro del tipo, hay 5–6 sub-categorías. Elige según objetivo, fecha en el calendario, distribución de los últimos 14 días (evita repetir misma sub-categoría dos veces seguidas). Elige formato (Reel, carrusel, foto + caption, Stories) según lo que el capítulo recomienda como dominante para ese tipo.

**Paso D — Construir la pieza usando los inputs del brief.**

- Si la pieza es Relacionamiento → usa Banco de Auto-Aplicación + Vulnerabilidades presentes + Momentos pivote
- Si es Polarización → usa Mapa de Creencias del Nicho (sección N)
- Si es Niveles de Consciencia → usa Mapa de Dolores del Avatar
- Si es Conversión → usa la regla de transparencia de precio según el ticket
- Si es Autoridad → usa credenciales, casos, datos del brief

**Paso E — Aplicar plantilla y ganchos del capítulo.**

Toma la plantilla de caption del capítulo. Elige UN gancho de la biblioteca (rotando entre los 20). Llena los movimientos con material del brief.

**Paso F — Validar contra errores comunes y reglas de seguridad.**

Antes de entregar, revisa contra los errores comunes del tipo (en el capítulo) y contra las reglas de seguridad transversales (`references/12-reglas-operativas.md`).

**Paso G — Entregar pieza con metadatos.**

Formato de entrega:
- Tipo y sub-categoría (ej. *"Polarización — sub: contra prácticas establecidas"*)
- Formato sugerido (Reel 60s / Carrusel 7 slides / etc.)
- Pieza completa (gancho + cuerpo + CTA)
- Notas operativas si aplica (mejor hora, plan de respuesta a comentarios, etc.)

---

## Workflow de calendario editorial

Cuando el usuario pida calendario semanal o mensual:

1. Confirma o consulta tipo de negocio y etapa de cuenta (paso 2 del protocolo de configuración).
2. Carga `references/11-arquitectura-calendario.md` para la matriz de proporciones del tipo de negocio.
3. Aplica modificadores de etapa (cuenta nueva +Engagement; lanzamiento activo +Conversión).
4. Distribuye los 8 tipos en los días planificados respetando los porcentajes.
5. Para cada slot, sugiere el tipo + sub-categoría + formato + gancho semilla. NO generes las 7–30 piezas completas a menos que el usuario lo pida; entrega el plan primero, las piezas después.
6. Incluye fechas especiales relevantes (ver `references/14-anexo-fechas-especiales.md`) y sugiere 1 pieza por fecha relevante al nicho.

**Regla crítica de calendario:** evita que la misma sub-categoría aparezca dos veces seguidas. Variedad sostiene atención.

---

## Workflow de lanzamiento (campaña 2–3 semanas)

Cuando el usuario indique lanzamiento de programa/producto/servicio:

1. Confirma fecha de apertura, duración del lanzamiento, oferta exacta, número de plazas/cupos, precio y condiciones (descuentos, bonos, garantías).
2. Aplica la **secuencia ideal de lanzamiento** definida en `references/10-tipo-conversion.md` sección 18.9. Resumen:
   - **Semana -2 (calentamiento):** Niveles 4–3 (Problem Aware → Solution Aware) + Relacionamiento con Banco de Auto-Aplicación conectado al producto + 1 Polarización
   - **Semana -1:** Niveles 2 (Product Aware) + Autoridad + 1–2 Transformación que muestren preview
   - **Día 0:** Conversión sub-categoría 1 (Anuncio) + DM personalizado a leads calientes
   - **Días 1–4:** Conversión sub-categoría 3 (Manejo objeciones) + sub-categoría 4 (Comparativa) + Niveles 2 reforzando
   - **Días 5–7:** Conversión sub-categoría 2 (Urgencia y escasez) + recordatorios diarios en Stories
   - **Día 7:** Reel de cierre + Stories cada hora últimas 8 h
   - **Día 8:** Conversión sub-categoría 5 (Re-engagement) para los que dudaron
3. Aplica **regla de transparencia de precio** según el ticket (ver `references/10-tipo-conversion.md` sección 18.5):
   - <$1.000: precio público según contexto
   - $1.000+: NO mostrar precio, driving a aplicación
   - >$5.000: NUNCA mostrar precio, llamada de aplicación obligatoria
4. Entrega plan de lanzamiento como tabla día×día. Las piezas individuales se generan a petición.

---

## Reglas de seguridad transversales (no negociables)

Independiente del tipo de contenido solicitado, NO produzcas:

1. **Contenido que ataque a personas, grupos vulnerables o protegidos.** Polarización es contra prácticas, mitos, tendencias — nunca contra personas o categorías.
2. **Contenido sobre temas no relacionados al nicho.** Política partidista, religión, identidad de género, conflictos geopolíticos no son terreno del método.
3. **Promesas absolutas sin condiciones.** Nada de *"te aseguro [resultado] en [tiempo]"* sin disclaimers.
4. **Falsa urgencia o escasez.** En Conversión, los números deben ser reales.
5. **Casos de cliente sin permiso explícito.**
6. **Sexualización o contenido inapropiado para el nicho.**
7. **Compartir DMs privados sin permiso.**
8. **Manipulación.** En coaching de habilidades sociales o seducción, distinguir desarrollo personal legítimo vs. técnicas de manipulación. NO producir contenido que cruce a manipulación.

Si el usuario pide algo que viola alguna de estas reglas, explica el conflicto, ofrece alternativa éticamente alineada, y si el usuario insiste, declina.

---

## Referencias — cuándo cargar cada archivo

**Carga al inicio del trabajo con un negocio/cliente:**
- `references/01-fundamentos.md` — Filosofía, los 8 tipos, cómo se relacionan, cómo se usa.
- `references/02-brief-y-mapas.md` — Brief completo, Banco de Auto-Aplicación, Mapa de Dolores 4 niveles.

**Carga cuando vayas a generar una pieza de ese tipo específico:**
- `references/03-tipo-relacionamiento.md`
- `references/04-tipo-engagement.md`
- `references/05-tipo-polarizacion.md`
- `references/06-tipo-transformacion.md`
- `references/07-tipo-interaccion-1x1.md`
- `references/08-tipo-niveles-consciencia.md`
- `references/09-tipo-autoridad.md`
- `references/10-tipo-conversion.md`

**Carga cuando el trabajo lo requiera:**
- `references/11-arquitectura-calendario.md` — Para calendario editorial, matriz de proporciones por tipo de negocio.
- `references/12-reglas-operativas.md` — Para validación de outputs, CTAs por tipo, transparencia de precio.
- `references/13-anexo-mapa-dolores-ejemplos.md` — Cuando necesites referencia de mapas en 4 nichos (belleza, IA, marketing digital, coaching).
- `references/14-anexo-fechas-especiales.md` — Para calendario que incluya fechas estacionales.
- `references/15-anexo-glosario.md` — Para clarificar terminología del método.
- `references/16-template-brief-marca.md` — Cuando el usuario pida llenar el brief modo estructurado.

**Patrón de carga eficiente:** no cargues todas las referencias de entrada. Carga solo la que necesitas para la tarea actual. Esto preserva contexto para iteración.

---

## Principios operativos

- **Específico vence genérico.** Una pieza con detalle exacto del avatar y del banco de auto-aplicación vale 10 piezas con language genérico. Si el usuario no entrega detalle, pídelo antes de generar.
- **Tono y voz del usuario por defecto, no IA por defecto.** Imita el patrón verbal del usuario tal como aparece en el brief (frases que repite, posturas, contradicciones, vulnerabilidades). NO impongas tono motivacional, corporativo o "experto en LinkedIn".
- **Idioma:** español por defecto a menos que el brief indique otro. Mantén el registro coloquial cuando el brief lo indique.
- **Una pieza, un objetivo.** No mezclar 2 tipos en la misma pieza. Cada tipo tiene mecánica propia; mezclarlos dilute ambos.
- **El usuario es la autoridad final sobre su avatar.** Si el usuario corrige un dolor, una postura, un dato — acepta la corrección, ajusta el material relacionado, no defiendas el output original.
- **Producción modular.** Cuando el usuario pida pieza, entregar pieza completa. Cuando pida calendario, entregar plan primero (no las 30 piezas). Cuando pida lanzamiento, entregar secuencia primero. Las piezas detalladas se producen bajo petición específica.
